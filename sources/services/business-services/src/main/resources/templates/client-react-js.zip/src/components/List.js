import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { Table } from '../containers/Table'
import { PageLoader } from './PageLoader'
import { Disclaimer } from '../containers/Disclaimer'
import { Redirect } from 'react-router-dom'
import 'bulma'
import 'bulma-pageloader'
import 'bulma-switch'



export class List extends Component{

  static propTypes ={
    results: PropTypes.array
  }
  constructor(props){
    super(props)

    this.state = {
      results: props.results || [],
      history: props.history,
      apiPath: props.apiPath,
      apiVersion: props.apiVersion,
      initialized: this.props.initialized || false,
      showObjects: false,
      usingDetails: this.props.usingDetails || false,
      token: JSON.parse(localStorage.getItem('JWT')).access_token
    }
  }

  _handleSwitchDisplay = (e) =>{
    this.setState({showObjects: !this.state.showObjects})
  }

  _handleDelete = (id, position) =>{
    const { results , history , apiPath, apiVersion } = this.state
    fetch(`${process.env.REACT_APP_SERVER}/api-manager/server/api/${apiVersion}/${apiPath}/${id}`,
    {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${this.state.token}`
      }
    })
    .then(res => {
      if(res.ok)
        return res.json()
      else
        throw res;
      }).then(r => {
      var current = results
      current.splice(position,1)
      this.setState({results: current})
    })
    .catch(e =>{
        history.push('/logout');
    })
  }
  componentWillReceiveProps(nextProps){
    if(this.props.apiPath !== nextProps.apiPath)
      this.setState({apiPath:nextProps.apiPath, apiVersion: nextProps.apiVersion,initialized:false})
  }

  componentDidUpdate(){
    this._fetchData()
  }
  componentDidMount(){
    this._fetchData()
  }

  _fetchData = () =>{
    const {initialized, history, apiPath, apiVersion} = this.state
    if(!initialized){
      fetch(`${process.env.REACT_APP_SERVER}/api-manager/server/api/${apiVersion}/${apiPath}`,
      {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Bearer ${this.state.token}`
        }
      })
      .then(res => {
        if(res.ok)
          return res.json()
        else{
          throw res;
        }
      })
      .then(r => this.setState({results:r, initialized:true}))
      .catch(e =>{
          history.push('/logout');
      })
    }
  }

  render(){
    const {results, initialized, showObjects, usingDetails, apiPath, apiVersion} = this.state

   if(!initialized)
      return (
          <PageLoader />
      )
   if(results.length === 0 && !usingDetails)
      return (
          <Disclaimer
            title='No data...'
            subtitle='Start creating new items'
            type='is-warning'/>
      )
    if(results.length === 0 && usingDetails)
      return (
        <Redirect to='/'/>
      )
    return (
      <Table
        apiPath={apiPath}
        apiVersion={apiVersion}
        showObjects={showObjects}
        results={results}
        deleteHandler={this._handleDelete}
        switchDisplayHandler={this._handleSwitchDisplay} />
    )
  }
}
