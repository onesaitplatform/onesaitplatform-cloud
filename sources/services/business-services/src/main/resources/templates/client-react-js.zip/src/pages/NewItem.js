import React, { Component } from 'react'
import {NavBar} from '../components/NavBar'
import {MenuVertical} from '../components/MenuVertical'
import { Form } from "../containers/Form";
import { Redirect } from 'react-router-dom'
import sample from '../data/sample.json'
import { JsonAccessHelper } from '../utils/JsonAccessHelper'


export class NewItem extends Component{

  state ={
    id: '',
    history: this.props.history,
    apiPath: this.props.match.params.api,
    apiVersion: this.props.match.params.version,
    object: sample[this.props.match.params.api],
    response: {},
    token: JSON.parse(localStorage.getItem('JWT')).access_token
  }

  _handleSubmit= (e) =>{
    const {history,object,apiPath,apiVersion} = this.state
    var o = object;
    delete o._id;
    e.preventDefault();
    console.log(o)
    fetch(`${process.env.REACT_APP_SERVER}/api-manager/server/api/${apiVersion}/${apiPath}`,
    {
      method: 'POST',
      body: JSON.stringify(o),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${this.state.token}`
      }

    }
    ).then(res =>{
      if(res.ok)
        return res.json()
      else
        throw res;
    })
    .then(r => this.setState({response:r}))
    .catch(e =>{
      if(e.status === 401)
        history.push('/logout')
      else{
        //TO-DO schema validation failed
      }

    })
  }

  _changeAttributeValue = (type, field, value) =>{
    const {object} = this.state
    console.log(object)
    try{
      switch (type) {
        case 'object':
          JsonAccessHelper(object)[field]=JSON.parse(value)
          break;
        case 'number':
          JsonAccessHelper(object)[field]=Number(value);
          break;
        case 'boolean':
          JsonAccessHelper(object)[field]=Boolean(value);
          break;
        case 'string':
        default:
          JsonAccessHelper(object)[field]=value;
          this.setState({object})
          break;


      }

    }catch(e){
      console.log(e)
    }
  }
  render(){
    const {response, apiPath, object, apiVersion} = this.state

    if(response['ids'] !== undefined){
      return (
        <Redirect to={`/apis/${apiPath}/${apiVersion}/detail/${response['ids'][0]}`}/>
      )
    }
    return (
      <div>
        <NavBar/>
        <div className="page-content-wrapper">
          <div className="page-content">
          <MenuVertical active={'newItem'} parent={`${apiPath}/${apiVersion}`}/ >
              <Form
                object={object}
                api={`${apiPath}/${apiVersion}`}
                submitFunction={this._handleSubmit}
                changeFunction={this._changeAttributeValue}/>
          </div>
        </div>
      </div>
    )
  }
}
