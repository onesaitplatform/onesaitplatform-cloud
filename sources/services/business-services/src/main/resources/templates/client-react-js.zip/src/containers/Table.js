import React from 'react'
import { Link  } from 'react-router-dom'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faEye, faEdit, faTrash } from '@fortawesome/free-solid-svg-icons'
import { JsonAccessHelper } from '../utils/JsonAccessHelper'
import { JsonIdExtractor } from '../utils/JsonIdExtractor'

export const Table = ({results, showObjects, switchDisplayHandler, deleteHandler, apiPath, apiVersion}) =>(
  <div>
    <div className="table-wrapper">

      <div className="field switch-container" >
        <input
        onChange={switchDisplayHandler}
        id="switchColorInfo" type="checkbox" className="switch is-info is-small"/>
        <label htmlFor="switchColorInfo">Show object fields</label>
      </div>

      <table className="table table-hover table-striped">
        <thead>
          <tr>
            {
              Object.keys(JsonAccessHelper(results[0]))
              .filter(f =>  showObjects ? true : typeof JsonAccessHelper(results[0])[f] !== 'object')
              .map(f => {
                  return <th key={f}>{f.toUpperCase()}</th>
              })
            }
            <th>OPTIONS</th>
          </tr>
        </thead>
        <tbody>
          {
            results.map((item,pos) => {
              let fields = Object.keys(JsonAccessHelper(item))
              return(
                <tr key={JsonIdExtractor(item)} id={JsonIdExtractor(item)}>
                  {
                    fields
                    .filter(field => showObjects ? true : typeof JsonAccessHelper(item)[field] !== 'object')
                    .map(field =>{
                      return <td className="dont-break-out" key={JsonIdExtractor(item) + field}>
                                {
                                    typeof JsonAccessHelper(item)[field] === 'object'
                                    ? <p className="pretty-print">{JSON.stringify(JsonAccessHelper(item)[field],null,2)}</p>
                                    : JsonAccessHelper(item)[field]
                                }
                            </td>
                    })
                  }
                  <td>
                      <span className="btn btn-xs btn-no-border btn-circle btn-outline blue" data-tooltip="Show">
                        <Link to={`/apis/${apiPath}/${apiVersion}/detail/${JsonIdExtractor(item)}`} className="icon-btn-table">
                          <FontAwesomeIcon style={{fontSize:'15px'}} icon={faEye}/>
                        </Link>
                      </span>
                      <span className="btn btn-xs btn-no-border btn-circle btn-outline blue" data-tooltip="Update">
                        <Link to={`/apis/${apiPath}/${apiVersion}/update/${JsonIdExtractor(item)}`} className="icon-btn-table">
                          <FontAwesomeIcon style={{fontSize:'15px'}} icon={faEdit}/>
                        </Link>
                      </span>
                      <span onClick={() => deleteHandler(JsonIdExtractor(item), pos)}
                        className="btn btn-xs btn-no-border btn-circle btn-outline blue" data-tooltip="Delete">
                        <FontAwesomeIcon style={{fontSize:'15px'}} icon={faTrash}/>
                      </span>
                  </td>
                </tr>
              )
            })
          }
        </tbody>
      </table>
    </div>
  </div>

)
