import React from 'react';
import { Redirect } from 'react-router-dom';

export const LogOut = () =>{
  localStorage.removeItem('JWT')
  return (
    <Redirect to='/'/>
  )
}
