
export const IsLogged = () => (
  localStorage.getItem('JWT') != null
)
