import React from 'react'
import { Link } from 'react-router-dom'
import logo from '../platform_logo.png'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faShareSquare, faUser } from '@fortawesome/free-solid-svg-icons'


export const NavBar = () =>(
  <nav className="navbar " role="navigation" aria-label="main navigation">
    <div className="navbar-brand">
    <div className="navbar-item">
      <Link  to='/'>
        <img src={logo} className="logo" alt="Bulma: a modern CSS framework based on Flexbox" width="112" height="28"/>
      </Link>
      onesait Platform API client
    </div>

    </div>
    <div className="navbar-end">
      <div className="navbar-item has-dropdown is-hoverable" style={{marginRight:'50px'}}>
        <a className="navbar-link">
          <span className="icon">
            <FontAwesomeIcon icon={faUser}/>
          </span>
          <span>
            {JSON.parse(localStorage.getItem('JWT')).name}
          </span>
        </a>

        <div className="navbar-dropdown">
          <span className="navbar-item">
            {JSON.parse(localStorage.getItem('JWT')).authorities[0]}
          </span>
          <hr className="navbar-divider"/>
          <Link to="/logout" className="navbar-item">
            <span className="icon">
              <FontAwesomeIcon icon={faShareSquare}/>
            </span>
            <span>Log out</span>
          </Link>
        </div>
      </div>
    </div>
  </nav>

)
