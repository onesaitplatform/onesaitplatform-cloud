import React, { Component } from 'react'
import { Link } from 'react-router-dom'

const APIS={{{APIS}}}

export class MenuVertical extends Component {
  state = {
    activeItem: this.props.active,
    parent: this.props.parent
  }

  handleItemClick = (e, { name }) => this.setState({ activeItem: name  })

  componentWillReceiveProps(nextProps){
    if(this.props.parent !== nextProps.parent)
      this.setState({parent:nextProps.parent})
  }
  render() {
    const { activeItem , parent} = this.state

    return (
      <aside className="menu">
        <p className="menu-label">
          APIs
        </p>
        <ul className="menu-list">
          {
            APIS.map(a =>
              <li key={`api-${a.name}-${a.version}`}><Link to={`/apis/${a.name}/${a.version}`}>{`${a.name.toUpperCase()}-${a.version}`}</Link></li>
            )
          }
        </ul>
        <hr/>
        {
          parent !== undefined
          ? <div>
            <p className="menu-label">
              {parent}
            </p>
            <ul className="menu-list">
              <li>
                <ul>
                  <li>
                      <Link
                        to={`/apis/${parent}`}
                        className={activeItem === 'list' ? 'is-active' : ''}>
                          List
                      </Link>
                  </li>
                  <li>
                      <Link
                        to={`/apis/${parent}/new-item`}
                        className={activeItem === 'newItem' ? 'is-active' : ''}>
                          New item
                      </Link>
                  </li>
                  <li>
                      <Link
                        to={`/apis/${parent}/dashboard`}
                        className={activeItem === 'dashboard' ? 'is-active' : ''}>
                          Dashboard
                      </Link>
                  </li>
                </ul>
              </li>
            </ul>
            </div>
          : <ul></ul>
        }
      </aside>
    )
  }
}
