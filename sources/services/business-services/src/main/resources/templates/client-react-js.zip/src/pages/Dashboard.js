import React, { Component } from 'react'
import {NavBar} from '../components/NavBar'
import {MenuVertical} from '../components/MenuVertical'

const DEFAULT_URL= "https://development.onesaitplatform.com/controlpanel/dashboards/viewiframe/MASTER-Dashboard-2?vertical=onesaitplatform&tenant=development_onesaitplatform"

const URL = {
  'restaurants-v1': 'https://development.onesaitplatform.com/controlpanel/dashboards/viewiframe/MASTER-Dashboard-2?vertical=onesaitplatform&tenant=development_onesaitplatform',
  'helsinki-v1': 'https://development.onesaitplatform.com/controlpanel/dashboards/viewiframe/MASTER-Dashboard-2?vertical=onesaitplatform&tenant=development_onesaitplatform'
}
export class Dashboard extends Component {

  state ={
    iframeHeight: '700px',
    iframeWidth: '1200px',
    apiPath: this.props.match.params.api,
    apiVersion: this.props.match.params.version,
    token: JSON.parse(localStorage.getItem('JWT')).access_token,
    url: ''
  }

  componentDidMount(){
    const {token,apiPath,apiVersion} = this.state
    const api = `${apiPath}-${apiVersion}`
    this.setState({url:`${URL[api] || DEFAULT_URL }&oauthtoken=${token}`})
  }


  render(){
    const {url,apiPath,apiVersion} = this.state
    return(
      <div>
        <NavBar/>
        <div className="page-content-wrapper">
          <div className="page-content">
            <MenuVertical active={'dashboard'} parent={`${apiPath}/${apiVersion}`}/ >
            <div className='table-wrapper'>
                <iframe
                  onLoad={this._adjustHeightIframe}
                  id='iframe'
                  style={{maxWidth:'100%', width:'1200px', height:this.state.iframeHeight, overflow:'auto'}}
                  title='dashboard'
                  src={url}/>
            </div>
          </div>
        </div>
      </div>
    )
  }

}
