import React, { Component } from 'react'
import {NavBar} from '../components/NavBar'
import {MenuVertical} from '../components/MenuVertical'
import { Form } from "../containers/Form";
import { Redirect } from 'react-router-dom'
import { PageLoader } from '../components/PageLoader'
import { JsonAccessHelper } from '../utils/JsonAccessHelper'


export class Update extends Component{

  state ={
    id: this.props.match.params.id,
    apiPath: this.props.match.params.api,
    apiVersion: this.props.match.params.version,
    history: this.props.history,
    initialized: false,
    updated: false,
    object: {},
    response: {},
    token: JSON.parse(localStorage.getItem('JWT')).access_token
  }

  _handleSubmit= (e) =>{
    const {apiPath,history,object,id, apiVersion} = this.state

    e.preventDefault();
    fetch(`${process.env.REACT_APP_SERVER}/api-manager/server/api/${apiVersion}/${apiPath}/${id}`,
    {
      method: 'PUT',
      body: JSON.stringify(object),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${this.state.token}`
      }
    }
    ).then(res =>{
      if(res.status===200 || res.status===204)
        return res.json()
      else
        throw res;
    })
    .then(r => this.setState({updated:true}))
    .catch(e =>{
      if(e.status === 401)
        history.push('/logout')
      else{
        //TO-DO schema validation failed
      }

    })
  }

  componentDidMount(){
    const {id, history, apiPath, apiVersion} = this.state
    fetch(`${process.env.REACT_APP_SERVER}/api-manager/server/api/${apiVersion}/${apiPath}/${id}`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${this.state.token}`
      }
    })
    .then(res => {
      if(res.ok)
        return res.json()
      else
        throw res;
      })
    .then(r => {
      console.log(r)
      delete r[0]._id
      this.setState({object:r[0], initialized: true})
    })
    .catch(e =>{
        history.push('/logout');
    })
  }

  _changeAttributeValue = (type, field, value) =>{
    const {object} = this.state
    console.log(object)
    try{
      switch (type) {
        case 'object':
          JsonAccessHelper(object)[field]=JSON.parse(value)
          break;
        case 'number':
          JsonAccessHelper(object)[field]=Number(value);
          break;
        case 'boolean':
          JsonAccessHelper(object)[field]=Boolean(value);
          break;
        case 'string':
        default:
          JsonAccessHelper(object)[field]=value;
          this.setState({object})
          break;


      }

    }catch(e){
      console.log(e)
    }
  }
  render(){
    const {updated,id, initialized, object, apiPath, apiVersion} = this.state
    if (!initialized)
      return <PageLoader/>
    if(updated){
      return (
        <Redirect to={`/apis/${apiPath}/${apiVersion}/detail/${id}`}/>
      )
    }
    return (
      <div>
        <NavBar/>
        <div className="page-content-wrapper">
          <div className="page-content">
          <MenuVertical active={''} parent={`${apiPath}/${apiVersion}`}/ >
            <Form
              api={`${apiPath}/${apiVersion}`}
              submitFunction={this._handleSubmit}
              changeFunction={this._changeAttributeValue}
              object={object}/>
          </div>
        </div>
      </div>
    )
  }
}
