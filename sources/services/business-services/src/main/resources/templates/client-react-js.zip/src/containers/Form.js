import React from 'react'
import sample from '../data/sample.json'
import { FormGroup, FormControl, FormLabel } from "react-bootstrap";
import { JsonAccessHelper } from '../utils/JsonAccessHelper'


export const Form=({submitFunction,changeFunction, api, object=sample[api]}) => (

  <form onSubmit={submitFunction} className="ods-form login-form__form table-wrapper">
      {
      Object.keys(JsonAccessHelper(object))
        .map(o =>
          typeof JsonAccessHelper(object)[o] !== 'object'
          ? <FormGroup key={o} controlId={o} >
            <FormLabel className="ods-form-item__label">{o}</FormLabel>
            <FormControl
              className="ods-input__inner"
              autoFocus
              type="text"
              required
              defaultValue={JsonAccessHelper(object)[o]}
              onChange={(e) => changeFunction(typeof JsonAccessHelper(object)[o], o, e.target.value)}
            />
          </FormGroup>
          :<FormGroup key={o} controlId={o} >
            <FormLabel className="ods-form-item__label">{o}</FormLabel>
            <FormControl
              row="4"
              as="textarea"
              defaultValue={JSON.stringify(JsonAccessHelper(object)[o])}
              onChange={(e) => changeFunction(typeof JsonAccessHelper(object)[o],o, e.target.value)} />
          </FormGroup>
        )
      }
      <div className="login-form__action">
        <button className="ods-button ods-button--primary is-round"  type="submit">
          Save
        </button>
      </div>
    </form>

)
