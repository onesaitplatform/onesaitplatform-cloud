import React, { Component } from 'react'
import {NavBar} from '../components/NavBar'
import {List} from '../components/List'
import { PageLoader } from '../components/PageLoader'
import {MenuVertical} from '../components/MenuVertical'
export class Detail extends Component{

  state ={
    id: this.props.match.params.id,
    history : this.props.history,
    apiPath: this.props.match.params.api,
    apiVersion: this.props.match.params.version,
    object: [],
    initialized: false,
    token: JSON.parse(localStorage.getItem('JWT')).access_token
  }



  componentDidMount(){
    const {id, history, apiPath, apiVersion} = this.state
    fetch(`${process.env.REACT_APP_SERVER}/api-manager/server/api/${apiVersion}/${apiPath}/${id}`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${this.state.token}`
      }
    })
    .then(res => {
      if(res.ok)
        return res.json()
      else
        throw res;
      })
    .then(r => {
      console.log(r)
      this.setState({object:r, initialized: true})
    })
    .catch(e =>{
        history.push('/logout');
    })
  }

  render(){
    const {initialized, object, apiPath, apiVersion} = this.state
    return (

      <div>
        <NavBar/>
        <div className="page-content-wrapper">

            {
              initialized
              ? <div className="page-content">
                  <MenuVertical active={'detail'} parent={`${apiPath}/${apiVersion}`}/ >
                  <List
                    apiPath={apiPath}
                    apiVersion={apiVersion}
                    initialized={initialized}
                    results={object}
                    usingDetails={true}/>
                </div>
              :<PageLoader/>

            }
        </div>
      </div>
    )
  }
}
