import React , { Component } from 'react'
import { FormGroup, FormControl, FormLabel, Alert } from "react-bootstrap";
import "../css/Login.css";
import PropTypes from 'prop-types'


const BASIC_AUTH = btoa('onesaitplatform:onesaitplatform');


export class Login extends Component {

    static propTypes = {
      username: PropTypes.string,
      password: PropTypes.string,
      failedLogin: PropTypes.bool,
      errorMessage: PropTypes.string
    }

    state = {
      username: '',
      password: '',
      failedLogin: false,
      errorMessage: ''
    }


    _handleSubmit =(e) =>{
      e.preventDefault();
      const { username , password } = this.state;
      const {history} = this.props
      const body = new URLSearchParams({
        username,
        password,
        grant_type: 'password',
        scope: 'openid'
      })
      fetch(`${process.env.REACT_APP_SERVER_OAUTH}/oauth-server/oauth/token`,
      {
        method: 'post',
        body: body,
        headers :{
           'Content-Type' : 'application/x-www-form-urlencoded;charset=UTF-8',
           'Authorization' : `Basic ${BASIC_AUTH}`
          }
      } )
      .then(res => {
        if(res.ok)
          return res.json()
        else
          return res.json().then(e => {throw e;})
          //res.json().then(r => )
      })
      .then(r =>{
        localStorage.setItem('JWT', JSON.stringify(r))
        history.push('/')
      })
      .catch(e => {
        this.setState({failedLogin:true, errorMessage:e.error_description})
      })
    }

    _validateForm = () =>{
        return this.state.username.length> 0 && this.state.password.length > 0;
    }


    render (){
      const { username, password, failedLogin, errorMessage} = this.state
      return (
        <div className="login__main">
          <form onSubmit={this._handleSubmit} className="ods-form login-form__form">
            {failedLogin
              ? <Alert variant='danger'>
                {errorMessage}
                </Alert>
              : ''
            }
            <h1 className="login__main__title">Login</h1>
            <FormGroup controlId="username" >
              <FormLabel className="ods-form-item__label">Username</FormLabel>
              <FormControl
                className="ods-input__inner"
                autoFocus
                type="text"
                onChange={e => this.setState({ username: e.target.value , password })}
              />
            </FormGroup>
            <FormGroup controlId="password" >
              <FormLabel className="ods-form-item__label">Password</FormLabel>
              <FormControl
                className="ods-input__inner"
                onChange={e => this.setState({ username , password: e.target.value })}
                type="password"
              />
            </FormGroup>
            <div className="login-form__action">
              <button className="ods-button ods-button--primary is-round" disabled={!this._validateForm()} type="submit">
                Login
              </button>
            </div>
          </form>
        </div>

    );
  }
}
