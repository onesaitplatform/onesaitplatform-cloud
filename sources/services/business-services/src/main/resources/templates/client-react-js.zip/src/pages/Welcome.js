import React from 'react'
import { MenuVertical } from '../components/MenuVertical'
import { NavBar } from '../components/NavBar'
import { Disclaimer } from '../containers/Disclaimer'
export const Welcome = () =>(
  <div>
    <NavBar/>
    <div className="page-content-wrapper">
      <div className="page-content">
        <MenuVertical/>
        <Disclaimer
          title='Welcome to the onesait Platform API client'
          subtitle='Choose an API and get started!'
          type='is-info'/>
      </div>
    </div>
  </div>

)
