import React , {Component} from 'react'
import {NavBar} from '../components/NavBar'
import {List} from '../components/List'
import {MenuVertical } from '../components/MenuVertical'
export class Home extends Component {

    state ={
      api: this.props.match.params.api,
      apiVersion : this.props.match.params.version,
      history: this.props.history
    }

  componentWillReceiveProps(nextProps){
    this.setState({api:nextProps.match.params.api, apiVersion: nextProps.match.params.version, history: nextProps.history})
  }

  render(){
    const {api, history, apiVersion} = this.state
    console.log(api)
    return (
        <div>
          <NavBar/>
          <div className="page-content-wrapper">
            <div className="page-content">
              <MenuVertical active='list' parent={`${api}/${apiVersion}`} />
              <List
                results={[]}
                history={history}
                apiPath={api}
                apiVersion={apiVersion}/>
            </div>
          </div>
        </div>
      )
    }
}
