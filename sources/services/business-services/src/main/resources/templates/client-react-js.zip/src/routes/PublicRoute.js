import React from 'react';
import { Route, Redirect } from 'react-router-dom';
import { IsLogged } from '../utils/IsLogged'

export const PublicRoute = ({component: Component, shouldRedirect, ...rest}) => {
    return (
        // restricted = false meaning public route
        // restricted = true meaning restricted route
        <Route {...rest} render={props => (
            IsLogged() && shouldRedirect?
                <Redirect to="/" />
            : <Component {...props} />
        )} />
    );
};
