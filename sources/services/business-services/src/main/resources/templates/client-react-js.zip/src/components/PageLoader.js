import React from 'react'

export const PageLoader = () =>{
  return (
    <div className="">
      <div className="pageloader is-active" style={{background:'rgb(112, 153, 189)'}}>
        <span className="title">Loading data...</span>
      </div>
    </div>
  )
}
