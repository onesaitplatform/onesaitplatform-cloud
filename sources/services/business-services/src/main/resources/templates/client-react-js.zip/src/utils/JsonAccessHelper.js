
export function JsonAccessHelper (object){
  let keys = Object.keys(object).filter(i => i !== "_id" && i!== "contextData");
  if(keys.length === 1){
    return object[keys[0]];
  }else{
    return object;
  }
}
