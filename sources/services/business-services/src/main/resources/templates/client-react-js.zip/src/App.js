import React, { Component } from 'react';
import './css/App.css';
import 'bootstrap/dist/css/bootstrap.css';
import './css/components.css';
import 'bulma/css/bulma.css'
import 'semantic-ui-css/semantic.min.css'
import { Switch } from 'react-router-dom'
import { Login } from './pages/Login'
import { LogOut } from './pages/LogOut'
import { Home } from './pages/Home'
import { Detail } from './pages/Detail'
import { PrivateRoute } from './routes/PrivateRoute'
import { PublicRoute } from './routes/PublicRoute'
import { Update } from './pages/Update'
import { NewItem } from './pages/NewItem'
import { Dashboard } from './pages/Dashboard'
import { Welcome } from './pages/Welcome'

class App extends Component {

  state = {
    userLogged : localStorage.getItem('JWT') != null
  }

  componentDidMount(){
    this.setState({userLogged : localStorage.getItem('JWT') != null})
  }
  render(){
    return (
      <div className="App">
        <Switch>
          <PublicRoute
            shouldRedirect={true}
            exact path='/login'
            component={Login}/>
          <PublicRoute
              shouldRedirect={false}
              exact path='/logout'
              component={LogOut}/>
          <PrivateRoute
              restricted={true}
              exact
              path='/'
              component={Welcome}/>
          <PrivateRoute
              restricted={true}
              exact path='/apis/:api/:version/detail/:id'
              component={Detail}/>
          <PrivateRoute
              restricted={true}
              exact path='/apis/:api/:version/update/:id'
              component={Update}/>
          <PrivateRoute
              restricted={true}
              exact path='/apis/:api/:version/new-item'
              component={NewItem}/>
          <PrivateRoute
              restricted={true}
              exact path='/apis/:api/:version/dashboard'
              component={Dashboard}/>
          <PrivateRoute
              restricted={true}
              exact
              path='/apis/:api/:version'
              component={Home}/>
        </Switch>
      </div>
    );
  }
}

export default App;
