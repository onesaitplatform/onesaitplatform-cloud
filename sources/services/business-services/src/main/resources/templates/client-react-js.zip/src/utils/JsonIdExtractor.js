
export function JsonIdExtractor (object){
  if(typeof object._id === 'object'){
    return object._id['$oid']
  }else{
      return object._id
  }
}
