/*  ############ MENU CONFIGURATION ###############################################################################
	Version 1.0
	Allow to load single nav-item or nav-items with submenus.
	Allow 3 different types of content: Links, Separators and Dashboards (iframe loaded)
		[Link]: link to other template 
		Fill url and leave dashboard empty "dashboard":{}
		
		[Separator]: just separator between nav-items
		Leave url empty "url":"" and leave dashboard empty "dashboard":{}
		
		[Dashboard]: leave url empty and fill dashboard object.
	
	CONFIGURATION OPTIONS:
	param			type					description
	---------------------------------------------------------------------------------------------------------------
	menu			String					name of menu.			
	rol				String					Rol of the user that load the menu
	home			Boolean					show or hide first nav-item (home, linked to index).
	favorite		Boolean					show or not the favorites dashboard nav-item
	favoritePos		String					'bottom' place on bottom of menu, other or not defined let at last nav-item
	noSession		String					template to go when there´s no session or expires.
	navigation		Array of Objects		The menu navigation items.
	
	--- ITEMs -----------------------------------------------------------------------------------------------------
	
	title			Object					nav-item title in english, spanish, ...loaded with <html lang="en" >
	icon			String					icon of the nav-item using icon fonts available flaticon- , fa- ,la-
	url				String					url of nav-item (http or https)
	submenu			Array of Objects		Array of nav-submen-items 
	dashboard		Object					Object with dashboard data configuration
	
	--- ITEMs > Dashboard -----------------------------------------------------------------------------------------
	
	src				String					url of Dashboard (http or https)
	title			String					Title of Dashboard	
	background		String					background Color (hex, rgb, rgba, hsl) (#FFF e.j.)
	height			String					Height of the iframe that contains the dashboard (850px e.j.)
	mode			String (op)				["INSERT","APPEND","AFTER"] defautl INSERT, not operative in V.1.0
	
*/

var host = window.location.origin;

// MENU JSON
var menuJson = {
    "menu": "OnesaitPlatform",
    "rol": "ROLE_DEVELOPER",
    "home": true,
	"favorite": true,
	"favoritePos": 'top',
	"noSession": "login.html",
    "navigation": [ 
		     
        {
            "title": {
                "EN": "Dashboards",
                "ES": "Dashboards"
            },
            "icon": "icon icon-dashboard",
            "url": "",
            "submenu": [
                {
                    "title": {
                        "EN": "Onesait Dashboard",
                        "ES": "Onesait Dashboard"
                    },
                    "icon": "flaticon-laptop",
                    "url": "",
                    "dashboard": {
                        "src": host+"/controlpanel/dashboards/viewiframe/MASTER-Dashboard-2",
                        "title": "Onesait Dashboard",
                        "background": "",
                        "height": "750px",
                        "mode": "INSERT",
			 "menu": "Dashboards"
                    }
                }
            ]
        }             
    ]
};


/*  ############ END MENU CONFIGURATION ############################################################################ */



/*  ############ PAGE CONFIGURATION ###############################################################################
	Version 1.0
	Allow to configure the main App text and the elements of the template.
	You can configure the App (main), Header (top bar elements), content (first data to load like first dashboard, ...)
	and Footer element and link.
	
	CONFIGURATION OPTIONS:
	param					type					description
	-----------------------------------------------------------------------------------------------------------------
	title					String					title of template <title>
	description				String					Description of page, (meta)
	access					Object					Access, Paths and entry mode for App.
	
	--- Access: -----------------------------------------------------------------------------------------------------
	
	urlBasePath				String					Path base to templates.
	imgBasePath				String					Path to images.
	entry					String					["PRIVATE","PUBLIC"] access mode free or with login.
	urlBase					String					Console base path
	urlApi					String					Console API base path
	realm					Boolean					Login into Realm or normal Login to platform
	realmConf				Object					if realm(Boolean) is active, the data to make login using Realm.
		realmId				String					Realm Id 
		secret				String					secret key to make oauth_token if empty it uses realmId
		clientId			String					client_Id to make login data.
	app						Object					App elements
	
	--- App: --------------------------------------------------------------------------------------------------------
	
	appLogo					String					img path string of logo image.
	appLogoCss				string					css for fixing custom logo.
	appSecondaryLogo		String					img path string of secondary header logo image.
	appSecondaryLogoCss		string					css for fixing custom secondary logo.
	appLogoBackground		String					color for background applied to logo container .m-brand__logo
	appHome					String					text of App title or Home show it in header.
	appLoading				Boolean					*
	appFooter,				Boolean					show footer section or not.
	appStickymenu			Boolean					show sticky right menu or not.
	appStickymenuRef		Object					documentation and support links 
	appWelcome				Boolean					show toastr notification with welcome or not.
	appDashboardsVue		Boolean					Dashboard load mode VUE or IFRAME 
	appHeaderLibs			Object					Object with CSS and Javascripts needed for dashboards (headerLibs)
		css					ArrayObjects			Array of CSS libraries to Load [name,src,loaded]
		js					ArrayObjects			Array of JS libraries to Load [name,src,loaded]
	
	login					Object					Login elements
	
	--- Login: --------------------------------------------------------------------------------------------------------
	
	loginLogo				String (url)			image for login template
	loginLogoStyle			String (css)			css for adjust imagen logo if defined
	loginBackground			String (css)			css for background of login
	loginDescription		String (text)			a description showed in login template 
	signInTitle				String (text)			title for sign in form
	signUp					Boolean 				show or not singUP toggle and form
	forgotPassword			Boolean					show or not forgot password toogle and form
	rememberMe				Boolean					show or not remember me chekbox.
	termsAndConditions		Boolean					show or not the terms and condition chekbox.
	agreeInfoMsg			String (url)			text for the agree condition and terms
	privacyLink				String (url)			url for privacy template or file 
	conditionsLink			String (url)			url for conditions template or file
	
	
	header					Object					Header (top bar) elements and toolbars.
	
	--- Header: --------------------------------------------------------------------------------------------------------
	
	headerDashboads			Boolean					show header dashboard menu or not
	headerReports			Boolean					show header Report menu or not
	headerSearch			Boolean					show header Search input or not
	headerNotifications		Boolean					show header Notifications menu or not
	headerQuickactions		Boolean					show header Quick Actions menu or not
	headerUser				Boolean					show header User menu or not
	headerSidebarToggle		Boolean					show header Sidebar menu or not
	headerRoles				Boolean					show or not the role selector on header and launch or not the role conf.

	user					Object					user header elements
	
	--- user: --------------------------------------------------------------------------------------------------------
	
	showAvatar 				Boolean					show avatar and email of user or not.
	avatar					String					image of user avatar if defined
	profile 				Object link				user Profile link
	support  				Object link				user support link
	activity				Object link				user activity link
	messages				Object link				user activity link
	faq						Object link				user faq link
	support					Object link				user support link
	logout 					Object link				user Logout  link function to logout.	
	
		
	content					Object					Content elements and data to initially Load
	
	--- Content: --------------------------------------------------------------------------------------------------------
	
	contentHead				Boolean					Show content head in card
	contentTitle			String					title of card in content
	contentTools			Boolean					show card tools (collapse and fullscreen)
	contentFavorites		Boolean					show favorites tools (toggle and reload)
	contentSave				Boolean					show save btn or not
	favorites				object					contains toogle and reload actions show or hide.
	contentPadding			String					modifies if defined, the padding of the content zone
	contentDashboard		Object Dashboard		contains the first dashboard to load initially on the page
	
	--- Content > contentDashboard: -------------------------------------------------------------------------------------
	
		enabled				Boolean					Enable the loading of this dashboard or not.
		dashboardName		String					Dashboard title
		changeTitle			Boolean					change or not the dashboard title in the card title content
		notification		Boolean					show notification toastr when dashboard is loading or not 
		src					String					url (http, https) of the dashboar to load.
		background			String					if provided (#FFF), the background of the iframe that loads de dashboard
		height				String					if provided (800px), the height of iframe that load the dashboard
		mode				String					["INSERT","APPEND","AFTER"] mode of loading, INSERT 
				
	
	footer					Object					Footer element and footer links	
	
	--- Footer: --------------------------------------------------------------------------------------------------------
	
	footerCopyright			String					Footer left text
	footerLinks				Boolean					show the links of the right part of the footer or not
	footerLinkAbout			Object link				Footer right link About
	footerLinkPrivacy		Object link				Footer right link Privacy
	footerLinkTerms			Object link				Footer right link Terms and conditions
	footerLinkCompany		Object link				Footer right link Company
	footerLinkSupport		Object link				Footer right link Support
	
	--- Footer > Object link: ------------------------------------------------------------------------------------------
		
		link				String					url (http,https) of the footer link
		text				String					text for the footer Link
		visible				Boolean					show or not that link
	
	
	themes					Object					App themes and styling configuration and settings
	
	--- Themes: --------------------------------------------------------------------------------------------------------
	
	skin					String					skin for the App [skin-light, skin-dark] not enabled in V.1.0
	contentBackground		String					if defined, backgroundColor of the content zone.
	footerBackground		String (css)			color of the background for footer section.
	
	
	TO-DO: Version 1.1
	--------------------------------------------------------------------------------------------------------------------
	- ALLOW CONFIGURATION ON REALTIME BY SESSIONSTORAGE OBJECT CLONE 
		- form with x-editable and functions to update values in obj and store changes in session.
		
	- More Styling , themes, menu , footer, header...
	
	
*/	

// FRONTEND MAIN CONFIGURATION
var mainJson = {
	"title": "Onesait Platform | Frontend Template.",
	"description": "Onesait Platform Frontend Template project",
	"currentSkin": "skin-light",
	"access":{
		"urlBasePath": "",
		"imgBasePath": "assets/app/media/img/",
		"entry": "PRIVATE",
		"urlBase":  host,
		"urlApi":  host + "/api-manager/server/api",
		"realm": false,
		"realmConf": {
			"realmId": "",
			"secret": "",
			"clientId": ""
		},
		"project": ""
	},
	"app": {
		"appLogo": "assets/app/media/img/logos/header.png",
		"appLogoCss": "width: auto; max-height: 60px;",
		"appSecondaryLogo":"assets/app/media/img/logos/Minsait-logo.png",
		"appSecondaryLogoCss":"width: 140px; height: auto;  margin-top: 10px;",
		"appLogoBackground": "background-color: #FFF !important",
		"appHome": "Onesait",
		"appLoading": "",
		"appFooter": true,
		"appStickymenu": true,
		"appStickymenuRef": {
			"documentation": "https://onesaitplatform.atlassian.net/wiki/spaces/OP/pages/177078320/Features",
			"support": "https://onesaitplatform.freshdesk.com"
		},
		"appWelcome": false,
		"appDashboardsVue": false,
		"appHeaderLibs":{
			"css":[{"src":"assets/vendors/datatables/datatables.bundle.css","name": "Datatables", "loaded": false},
				{"src":"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css","name": "font", "loaded": false},
				{"src":"https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.css","name": "datetimepicker", "loaded": false}],
			"js": [
				{"src":"assets/vendors/datatables/datatables.bundle.js","name": "Datatables", "loaded": false},
				{"src": "https://cdnjs.cloudflare.com/ajax/libs/echarts/4.2.1/echarts.min.js","name": "ECharts 4.2.1 min.","loaded": false},
				{"src": "https://cdnjs.cloudflare.com/ajax/libs/echarts/4.2.1/echarts.common.min.js","name": "ECharts 4.2.1 common","loaded": false},
				{"src": "https://cdnjs.cloudflare.com/ajax/libs/echarts/4.2.1/extension/bmap.min.js","name": "ECharts 4.2.1 bmap","loaded": false},
				{"src": "https://cdnjs.cloudflare.com/ajax/libs/echarts/4.2.1/extension/dataTool.min.js","name": "ECharts 4.2.1 dataTool","loaded": false},
			
				{"src": "https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.min.js","name": "datetimepicker","loaded": false},
				{"src": "https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js","name": "moment","loaded": false},
				{"src": "https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.17.21/lodash.min.js","name": "lodash","loaded": false}
			]
		}
	},
	"login":{
			"loginLogo": "assets/app/media/img/logos/onesait-platform-logo.png",
			"loginLogoStyle": "",
			"loginBackground": "assets/app/media/img/bg/bg-2.jpg",
			"loginDescription":"Welcome to Onesait Frontend",
			"signInTitle": "Sign in on Onesait Frontend:",
			"signInBtnColor": "", 
			"signUp": false,
			"forgotPassword": false,
			"rememberMe": false,
			"termsAndConditions": true,
			"agreeInfoMsg": "Please, check the agree Privacy and Terms to access",
			"privacyLink": "",
			"conditionsLink":""
	},
	"user":{
			"showAvatar": true,
			"avatar": "assets/app/media/img/logos/onesait.png",			
			"profile":  {"link":"profile.html","text":"ROL","visible": false},
			"support":  {"link":"support.html","text":"Support","visible": false},
			"activity": {"link":"activity.html","text":"Activity","visible": false},
			"messages": {"link":"messages.html","text":"Messages","visible": false},
			"faq":	  {"link":"faq.html","text":"FAQ","visible": false},			
			"logout":   {"link":"login.html","text":"Exit","visible": true}
	},
	"header": {
		"headerDashboads": false,
		"headerReports": false,
		"headerSearch": false,
		"headerNotifications": false,
		"headerQuickactions": false,
		"headerUser": true,
		"headerRoles": false,
		"headerSidebarToggle": false,
		"headerSessionConfiguration": false
	},
	"content": {
		"contentHead": true,
		"contentTools": false,
		"contentFavorites": false,
		"contentFilters": false,
		"contentSave": false,
		"favorites":{
			"toggle": true,
			"reload":true
		},
		"contentTitle": "Onesait Dashboards",
		"contentHeadCss": "height: 4rem; background: #f5f7f9; border-bottom: 1px dotted #CCC; margin-bottom: 6px;",		
		"contentTitleCss": "",		
		"contentDashboard": {
			"enabled": true,
			"dashboardName": "Onesait Dashboard",
			"changeTitle": false,
			"notification": false,
			"src": host + "/controlpanel/dashboards/viewiframe/MASTER-Dashboard-2",
			"background": "white",
			"height": "750px",
			"mode": "INSERT"
		}		
	},
	"footer": {
		"footerCopyright": "2021 &copy; Onesait Platform.",
		"footerLinks": true,
		"footerLinkAbout":  {"link":"https://www.onesait.com/platform","text":"About","visible": false},
		"footerLinkPrivacy":{"link":"privacy.html","text":"Privacy","visible": true},
		"footerLinkTerms":  {"link":"terms.html","text":"Terms","visible": true},
		"footerLinkCompany":{"link":"https://www.minsait.com/es","text":"Mindsait","visible": true},
		"footerLinkSupport":{"link":"support.html","text":"Onesait Support Center","visible": false}		
	},
	"themes":{
		"availableSkin": ["skin-light","skin-dark"],
		"changeSkin": "skin-dark",
		"contentBackground" : "ghostwhite",
		"contentPadding": "0px 0px",
		"menu": "",
		"footerBackground": "#FFF"
	}
};

// EMIT GLOBAL FILTERS STATUS
//window.globalFilters = mainJson.content.contentFavorites;
