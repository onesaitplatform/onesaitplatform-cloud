// GLOBAL VAR
var host	= window.location.origin;
var filters = window.globalFilters;

// VUE APP 
var vueapp = new Vue({
  el: '#app',
  data: {
    jsongadget: {},
	api: {},
	glist: [],
	activeFilters: filters,
    country: 'init',
    i: 0,
    options: [{"codent":'0042',"literal": "Entidad 1"},{"codent":'0043',"literal": "Entidad 2"},{"codent":'0044',"literal": "Entidad 3"}],
    tabactive: 'first',
    bodyStyle: {
      "padding": "0px"
    },
    editmode: false,
    i18n: false,
	selected: '',
    params:{
      country: '',
	  entity: '',
	  daterange: '',
	  segment:''
    },
    platformbase: host !== '' ? host : "https://lab.onesaitplatform.com/",
    token: sessionStorage.getItem("accessToken"),
    dashboard: "MASTER-Dashboard-2"
    
  },
  methods: {
    swapBoard(dashboardId) {
	  this.dashboard = dashboardId;
    },
	reloadFavorites(){
      window.DSApi["inst1"].api.favoriteService.getAllIdentifications().then(function(list){      
        vueapp.glist =[];
        for(var gad in list){
          vueapp.glist.push({'id':list[gad], 'title':list[gad], 'type': 'favoritegadget'  });
        }
        
       });
    },
    loadFromDS() {
		// load entities for filter and call frontend
		window.DSApi["inst1"].api.ds.get('satflv19_codent_tdim_ES_dmo_01')
		.then(
			data => { this.options = data;
					console.log('data filter loaded: ' + JSON.stringify(data));
					$("#entities").select2({placeholder:"Seleccionar Entidad"});
			}
		); 
    },
    sendFilter(e) {
	  var id = "external-entity";
	  console.log('sending params ...' + selected);
	  // usar params.entity en vez de selected
      window.DSApi["inst1"].api.sendFilter(id, "codent", this.selected);
      
    },   
    saveDashboard() {
      window.DSApi["inst1"].api.msgApi({ "command": "saveDashboard", "authorization": this.token, "information": { "dashboard": this.dashboard } });
	  toastr.success('The Dashboard is Saved.', 'Info:');
    },
    dragStartHandler(ev) {
      if (ev.dataTransfer) {
        ev.dataTransfer.setData('type', 'livehtml');
        ev.dataTransfer.dropEffect = 'copy';
      }
    },
    addData: function(item,e){
		if (item.type !== 'livehtml'){
			e.dataTransfer.setData('gid', item.id);
			e.dataTransfer.setData('title', item.title);
			e.dataTransfer.setData('type', item.type);
		}
		else{
			e.dataTransfer.setData('title', item.title);
			e.dataTransfer.setData('type', 'livehtml');
			e.dataTransfer.setData('config', item.config);
		}
    },
    addDataTemplate: function(item,e){
      e.dataTransfer.setData('title', "Select Gadg");
      e.dataTransfer.setData('type', 'livehtml');
      e.dataTransfer.setData('config', JSON.stringify({
        'params': [
          { "label": "signalName", "value": "countries"}, 
          { "label": "parameter-fromDataSource-value", "value": { "field": "countrysrc", "type": "string" }}, 
          { "label": "parameter-fromDataSource-label", "value": { "field": "countrysrc", "type": "string" }}],
        'template': 'Select',
        'subtype': "angularJS",
        "datasource": {
          id: "MASTER-GadgetDatasource-4",
          name: "countriesAsDestination",
          refresh: 0,
          type: "query"
        }
      }));
    },
	addRawGadget: function(item,e){
      e.dataTransfer.setData('title', item.title);
      e.dataTransfer.setData('type', 'livehtml');
      e.dataTransfer.setData('config', item.config);
    } 
  },
  mounted: function () {
	console.log('|--> VUEAPP MOUNTED ---> GLOBAL FILTERS: ' + this.activeFilters );
    
  }/*,
   components: {
		'v-chart':VueECharts
  } */
});

window.addEventListener('gadgetloaded',function(e){
  console.log(e.detail);
});

window.addEventListener("message",function(event){
  
  if(event.data == "dashboardloaded"){   
	// GET FAVORITES
    window.DSApi["inst1"].api.favoriteService.getAllIdentifications().then(function(list){      
		vueapp.glist = [];
		for(var gad in list){
			vueapp.glist.push({'id':list[gad], 'title':list[gad], 'type': 'favoritegadget'  });
		} 
	});
	
	// GET FILTERS
	vueapp.loadFromDS();
  }
  if(event.data == "addNewFavoriteGadget"){
     window.DSApi["inst1"].api.favoriteService.getAllIdentifications().then(function(list){
      
      vueapp.glist =[];
      for(var gad in list){
        vueapp.glist.push({'id':list[gad], 'title':list[gad], 'type': 'favoritegadget'  });
      }
      
     });
  }
})

window.addEventListener('gadgetselect',function(e){
  vueapp.jsongadget = e.detail;
  console.log(e.detail);
});

window.addEventListener('resize', function(e){
	window.DSApi["inst1"].api.forceRender()
});
