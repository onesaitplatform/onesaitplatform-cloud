<!--FULL GUIDE https://github.com/KlausSchaefers/figma-low-code-->

<template>

  <div class="home">
      <Figma :figma="figmaConfig" v-model="viewModel" :config="config"/>
  </div>

</template>

<script>

import Vue from "vue";
import Figma from 'vue-low-code'
import MainService from './../js/MainService'
{{{IMPORT}}}
Vue.use(Figma);



export default {
    name: 'Home',
    data: function() {
        return {
            // figmaJSON: app,
            figmaConfig: {
                figmaFile: '{{FIGMA_FILE}}',
                figmaAccessKey: '{{FIGMA_TOKEN}}',
            },
            viewModel: {
              //HERE GOES MOCK DATA, OR INITIAL VALUES
            },
            config: {
                components: {
                  {{COMPONENTS}}
                }
            }
        }
    },
    components: {},
    methods: {
     {{{METHODS}}}
   }
}

</script>
