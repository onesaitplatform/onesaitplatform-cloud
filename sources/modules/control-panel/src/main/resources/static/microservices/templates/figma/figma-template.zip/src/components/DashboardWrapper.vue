<!--FOR FULL GUIDE GO TO https://onesaitplatform.atlassian.net/wiki/spaces/OP/pages/1041629206/C+mo+incluir+Dashboards+en+tu+aplicaci+n+Vue+Dashboard4Vue+Wrapper-->

<template>
  <div>
    <Wrapper
      :api="api"
      :params="params"
      id="inst1"
      style="height:1000px;width:100%;position:absolute"
      editmode="{{EDIT_MODE}}"
      :dashboard="dashboard"
      :token="token"
      :platformbase="platformbase"
      i18n="false"></Wrapper>
  </div>
</template>

<script>

import Wrapper from './VueWrapperComponent.vue';

export default {
  name: '{{DASHBOARD_NAME}}',
  components: {
    Wrapper
  },
  data: function(){
    return {
      dashboard: "{{DASHBOARD_ID}}",
      token: `${JSON.parse(localStorage.getItem('JWT')).access_token}`,
      platformbase: "{{SERVER_NAME}}",
      params: {},
      api: {}
    }
  }
}
</script>

<style>
</style>
