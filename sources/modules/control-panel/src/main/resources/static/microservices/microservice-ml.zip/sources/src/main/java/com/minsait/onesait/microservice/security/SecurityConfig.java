package com.minsait.onesait.microservice.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.client.OAuth2ClientContext;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;

@EnableOAuth2Client
@Configuration
@Order(1)
public class SecurityConfig extends ResourceServerConfigurerAdapter {
	@Autowired
	private OAuth2ClientContext oauth2ClientContext;

	@Override
	public void configure(HttpSecurity http) throws Exception {
		// http.formLogin().loginPage("/login.html").loginProcessingUrl("/login").permitAll();

		http.csrf().disable();
		http.logout();
		http.authorizeRequests().antMatchers("/login**", "/**/*.css", "/img/**", "/third-party/**", "/").permitAll();
		http.authorizeRequests().antMatchers("/health/", "/info", "/metrics", "/trace", "/logfile", "/actuator/**").permitAll();
		http.authorizeRequests().regexMatchers("^/swagger.*", "^/v2/api-docs.*").permitAll();
		http.authorizeRequests().antMatchers("/models/**").authenticated();
		http.exceptionHandling().authenticationEntryPoint(new LoginUrlAuthenticationEntryPoint("/"));

	}

}