#/bin/sh
echo .
echo "usage: docker-build.sh [microservice_name]"
echo .
MICROSERVICE_NAME=$1
echo "Building microservice image $MICROSERVICE_NAME"
# Comment / Uncomment to use behind proxy
docker build -t $MICROSERVICE_NAME .
#docker build -t $MICROSERVICE_NAME --build-arg http_proxy=http://<proxyhost>:<port> --build-arg https_proxy=http://<proxyhost>:<port> .
echo .....................OK
echo .
