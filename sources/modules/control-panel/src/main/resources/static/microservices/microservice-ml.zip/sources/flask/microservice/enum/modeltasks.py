from enum import Enum

class ModelTasks(Enum):
    TRAIN = "TRAIN"
    RELOAD = "RELOAD"