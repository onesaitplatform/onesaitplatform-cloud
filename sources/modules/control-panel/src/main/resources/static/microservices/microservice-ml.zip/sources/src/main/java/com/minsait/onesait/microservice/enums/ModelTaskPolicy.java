package com.minsait.onesait.microservice.enums;

public enum ModelTaskPolicy {
	ALL, ONLY_ONE

}
