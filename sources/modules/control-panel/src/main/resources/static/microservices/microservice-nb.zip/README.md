# Modulo Notebook As A Service

Archivos de deploy para generar un microservicio a partir de un Notebook de plataforma.

Descripción de las carpetas:
- base: Carpeta para generar una imagen base.
- base-python: Carpeta para generar una imagen base-python con python a partir de la imagen base inicial.
- notebook: Carpeta para generar la imagen con el notebook a partir de la imagen base o de la imagen base-python si el notebook usa python.
