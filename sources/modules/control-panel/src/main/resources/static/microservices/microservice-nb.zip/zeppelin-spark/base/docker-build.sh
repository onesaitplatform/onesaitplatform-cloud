#/bin/sh
if [ "$(docker images -q zeppelin_alpine:latest)" = "" ]; then
  echo .
  echo "Base image 'zeppelin_alpine' not found... creating"
  # Comment / Uncomment to use behind proxy
  docker build -t zeppelin_alpine .
  #docker build -t zeppelin_alpine --build-arg http_proxy=http://<proxyhost>:<port> --build-arg https_proxy=http://<proxyhost>:<port> .
  echo .....................OK
  echo .
fi