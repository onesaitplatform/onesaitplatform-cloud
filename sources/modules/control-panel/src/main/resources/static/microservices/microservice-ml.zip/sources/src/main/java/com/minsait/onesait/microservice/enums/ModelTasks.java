package com.minsait.onesait.microservice.enums;

public enum ModelTasks {
	TRAIN, RELOAD

}
