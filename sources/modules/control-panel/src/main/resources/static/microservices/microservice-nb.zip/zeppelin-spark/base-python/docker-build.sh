#/bin/sh
if [ "$(docker images -q zeppelin_alpine_python:latest)" = "" ]; then
  echo .
  echo "Base image 'zeppelin_alpine_python' not found... creating"
  # Comment / Uncomment to use behind proxy
  docker build -t zeppelin_alpine_python .
  #docker build -t zeppelin_alpine_python --build-arg http_proxy=http://<proxyhost>:<port> --build-arg https_proxy=http://<proxyhost>:<port> .
  echo .....................OK
  echo .
fi