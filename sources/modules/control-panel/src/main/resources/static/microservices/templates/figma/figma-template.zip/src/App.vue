<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style lang="scss">
html,
body,
.home{
  min-height: 100%;
}
</style>
