import router from "../router/index";

class MainService {

  constructor(){
    this.server = '{{SERVER_NAME}}';
  }
  {{{MAIN_METHODS}}}
  {{{LOGIN_METHOD}}}
}


export default new MainService
