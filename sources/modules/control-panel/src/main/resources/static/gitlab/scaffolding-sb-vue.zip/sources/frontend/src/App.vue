<template>
  <div id="app">
    <template v-if="this.$route.name !== 'login-form'">
      <ods-container>
        <ods-aside width="72px">
          <side-navigation></side-navigation>
        </ods-aside>
        <ods-container>
          <ods-header>
            <the-header></the-header>
          </ods-header>
          <ods-main>
            <router-view></router-view>
          </ods-main>
        </ods-container>
      </ods-container>
    </template>
    <template v-else>
      <router-view></router-view>
    </template>
  </div>
</template>

<script>
import SideNavigation from '@/components/SideNavigation'
import TheHeader from '@/components/TheHeader'
export default {
  name: 'App'
  ,
  components: {
    SideNavigation,
    TheHeader
  }
  
}
</script>

<style>
html, body {
  font-family: 'Soho', Helvetica, Arial, sans-serif!important;
  -webkit-font-smoothing: subpixel-antialiased;
  font-kerning: none;
  background: #f5f7fa;
}
</style>
