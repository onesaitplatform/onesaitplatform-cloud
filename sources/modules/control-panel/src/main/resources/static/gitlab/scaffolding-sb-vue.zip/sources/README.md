
## Before compiling
1. Go to onesait-project-template\sources
2. If you don´t have Node.js installed do it from https://nodejs.org/es/download/. One installed verify your version with >node -v. If you have a Node version=>8 is OK
3. (Node.js has a version of npm, but it´s better to have the last version). Execute >npm install npm@latest -g.
4. (Optional)Execute >npm install --global vue-cli

## How to compile and execute:

1. Go to onesait-project-template\sources
2. Execute >mvn clean install
3. Execute >java -jar backend/target/onesait-example-backend-1.0.0-SNAPSHOT-exec.jar
4. Open a browser in http://localhost:17000/example-project

## Reference
You can see this tutorial in order to understand the organization of the project:
https://blog.codecentric.de/en/2018/04/spring-boot-vuejs/
