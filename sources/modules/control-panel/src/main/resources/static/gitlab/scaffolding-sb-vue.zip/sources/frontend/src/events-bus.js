import Vue from "vue";

export let EventsBus = new Vue()