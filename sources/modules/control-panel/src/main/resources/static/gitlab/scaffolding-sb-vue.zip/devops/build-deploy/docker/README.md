# Como desplegar con Docker Compose

1.- Es necesario levantar la capa de persistencia, para ello en el directorio devops/build-deploy/docker/data ejecutamos **docker-compose up -d**

2.- Poblar de datos la base de datos de configuración (configdb) y de tiempo real (realtimedb) desde el mismo directorio devops/build-deploy/docker/data ejecutamos **docker-compose -f docker-compose.initdb.yml up -d** con este comando se levantará un contenedor efímero que creará tablas/colecciones y realizará inserciones de datos para que, posteriormente, podamos levantar el control panel y los distintos módulos de la onesait platform

3.- Levantar el control panel de la onesait platform. Desde el directorio devops/build-deploy/docker/modules ejecutamos **docker-compose up -d**, una vez levantado lo tendremos accesible en la url: http://localhost:8091/controlpanel
