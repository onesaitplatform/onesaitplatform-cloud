export default function getEntityGeometry(entity) {
  if (!entity) return

  /** Return the current entity geometry type */
  if (entity.billboard) return 'billboard'
  else if (entity.point) return 'point'
  else if (entity.polyline) return 'linestring'
  else if (entity.polygon) return 'polygon'
}
