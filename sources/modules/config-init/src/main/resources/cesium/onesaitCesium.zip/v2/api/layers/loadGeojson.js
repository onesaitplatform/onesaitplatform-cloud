import updateLayersDropdown from '../ui/updateLayersDropdown.js'
import handleEntityPopup from '../popup/handleEntityPopup.js'

export default function loadGeojson(inputConfig, map) {
  if (!map || !inputConfig || !inputConfig.json || !inputConfig.id) return

  /** Set the params */
  const json = inputConfig.json
  const id = inputConfig.id
  const name = inputConfig.name ? inputConfig.name : inputConfig.id
  const geometryType = inputConfig.json.typeGeometry.toLowerCase()
  const iconSymbology = inputConfig.symbology.innerColorHEX
  const symbology = inputConfig.symbology
    ? cleanSymbology(geometryType, inputConfig.symbology)
    : setDefaultSymbology(geometryType)
  const filters =
    inputConfig.symbology.filters.length > 0
      ? clearFilters(inputConfig.symbology.filters)
      : undefined

  /** Check if the dataSource already exists */
  const existingDataSource = map.dataSources._dataSources.find(
    x => x.layerProperties && x.layerProperties.id === id
  )

  existingDataSource
    ? updateLayer(
        existingDataSource,
        json,
        geometryType,
        symbology,
        filters,
        map
      )
    : createLayer(
        json,
        id,
        name,
        geometryType,
        iconSymbology,
        symbology,
        filters,
        map
      )
}

function createLayer(
  json,
  id,
  name,
  geometryType,
  iconSymbology,
  symbology,
  filters,
  map
) {
  /** Create and add the dataSource; then update it entities */
  map.dataSources
    .add(
      Cesium.GeoJsonDataSource.load(json, {
        clampToGround: true
      })
    )
    .then(dataSource => {
      /** Set the dataSource properties */
      dataSource.layerProperties = {}
      dataSource.layerProperties.id = id
      dataSource.layerProperties.name = name
      dataSource.layerProperties.geometryType =
        geometryType === 'polyline' ? 'linestring' : geometryType
      dataSource.layerProperties.type = 'vector'

      /** Update the entities */
      updateEntities(
        geometryType,
        dataSource.entities.values,
        symbology,
        filters
      )

      /** Add the layer to the layers dropdown */
      updateLayersDropdown({
        id: id,
        name: name,
        type: 'vector',
        geometry: geometryType,
        symbology: iconSymbology
      })

      /** Make sure that lineString dataSources are always on top */
      map.dataSources._dataSources.forEach(ds => {
        if (ds.layerProperties.geometryType === 'linestring')
          map.dataSources.raiseToTop(ds)
      })

      /** Add the layer to the layer list */
      map.mapProperties.layers.vector.push(dataSource)

      updateSelectByAttributesLayersList(map)

      const selectByAttributesButton =
        document.getElementById('selectByAttributes')

      /** Enable the map legend button if disabled */
      if (selectByAttributesButton.classList.contains('disabled')) {
        selectByAttributesButton.classList.remove('disabled')
      }
    })
}

function updateLayer(
  dataSource,
  geojson,
  geometryType,
  symbology,
  filters,
  map
) {
  /** Clear the dataSource */
  dataSource.entities.removeAll()

  /** Close any popup, if showing */
  handleEntityPopup(map)

  /** Set a list to store all the entities to add */
  const entities = []

  /** Create a GeoJson datasource to get access to the entities */
  Cesium.GeoJsonDataSource.load(geojson).then(data => {
    data.entities.values.forEach(entity => {
      entities.push(entity)
    })

    /** Update the symbology of the new entities */
    updateEntities(geometryType, entities, symbology, filters)

    /** Add the new entities to the existing datasource */
    entities.forEach(entity => dataSource.entities.add(entity))
  })
}

/** This function will prepare the correct symbology type for each geometry */
function cleanSymbology(geometryType, simb) {
  let symbology

  switch (geometryType) {
    case 'point':
      symbology = {
        pixelSize: simb.pixelSize,
        color: Cesium.Color.fromCssColorString(simb.innerColorHEX).withAlpha(
          simb.innerColorAlpha
        ),
        outlineColor: Cesium.Color.fromCssColorString(
          simb.outlineColorHEX
        ).withAlpha(simb.outerColorAlpha),
        outlineWidth: simb.outlineWidth,
        heightReference: Cesium.HeightReference.RELATIVE_TO_GROUND,
        disableDepthTestDistance: Number.POSITIVE_INFINITY
      }
      break

    case 'polyline':
      symbology = {
        width: simb.outlineWidth,
        material: Cesium.Color.fromCssColorString(simb.innerColorHEX).withAlpha(
          simb.innerColorAlpha
        ),
        heightReference: Cesium.HeightReference.RELATIVE_TO_GROUND,
        disableDepthTestDistance: Number.POSITIVE_INFINITY
      }
      break

    case 'polygon':
      symbology = {
        material: Cesium.Color.fromCssColorString(simb.innerColorHEX).withAlpha(
          simb.innerColorAlpha
        ),
        outline: true,
        outlineColor: Cesium.Color.fromCssColorString(
          simb.outlineColorHEX
        ).withAlpha(simb.outlineColorAlpha)
      }

    default:
      break
  }

  return symbology
}

/** Rewrite the filters to make them more dev-friendly */
function clearFilters(filters) {
  const operators = ['==', '>', '<', '!=']
  const filterList = []

  filters.forEach(filter => {
    /** Get the operator type */
    const operator = operators.find(oper => filter.operation.includes(oper))

    /** Get the key and value */
    const key = filter.operation.split(operator)[0]
    const value = filter.operation.split(operator)[1]

    /** Add the filter, with it color, to the filter list */
    filterList.push({
      key: key,
      operator: operator,
      value: value,
      color: filter.colorHEX
    })
  })

  return filterList
}

function setDefaultSymbology(geometryType) {
  const defaultSymbology = {
    point: {
      radius: 20,
      color: Cesium.Color.fromCssColorString('#67ADDF'),
      outlineWidth: 1,
      outlineColor: Cesium.Color.BLACK
    },
    linestring: {
      //
    },
    polygon: {
      //
    }
  }

  return defaultSymbology[geometryType]
}

function updateEntities(geometryType, entities, symbology, filters) {
  switch (geometryType) {
    case 'point':
      updatePoints(entities, symbology)
      break
    case 'polyline':
      updateLineStrings(entities, symbology)
      break
    case 'polygon':
      updatePolygons(entities, symbology, filters)
      break
  }
}

function updatePoints(entities, symbology) {
  /** Check the type of symbology */
  entities.forEach(entity => {
    entity.entityProperties = {}
    entity.entityProperties.symbology = symbology

    /** Remove the marker */
    entity.billboard = undefined

    /** Add the symbology */
    entity.point = symbology
  })
}

function updateLineStrings(entities, symbology) {
  entities.forEach(entity => {
    entity.entityProperties = {}
    entity.entityProperties.symbology = symbology
    const lineString = entity.polyline

    /** Add the symbology */
    lineString.width = symbology.width
    lineString.material = symbology.material
    lineString.heightReference = symbology.heightReference
    lineString.disableDepthTestDistance = symbology.disableDepthTestDistance
  })
}

function updatePolygons(entities, symbology, filters) {
  entities.forEach(entity => {
    const polygon = entity.polygon

    /** Add the default symbology */
    polygon.material = symbology.material
    polygon.outline = true
    polygon.outlineColor = symbology.outlineColor

    /** Check if will be a filtered symbology */
    if (filters) {
      filters.forEach(filter => {
        const key = filter.key
        const value = filter.value
        const operator = filter.operator
        const color = filter.color
        const alpha = symbology.material.alpha
        const entityKey = entity.properties[key]

        /** Check if the property exists, and then check the value */
        if (entityKey) {
          const entityValue = entityKey.getValue()
          const newColor =
            Cesium.Color.fromCssColorString(color).withAlpha(alpha)

          switch (operator) {
            case '>':
              if (entityValue > value) {
                polygon.material.color.setValue(newColor)
              }
              break
            case '<':
              if (entityValue < value) {
                polygon.material.color.setValue(newColor)
              }
              break
            case '==':
              if (entityValue === value) {
                polygon.material.color.setValue(newColor)
              }
              break
            case '!=':
              if (entityValue !== value) {
                polygon.material.color.setValue(newColor)
              }
              break
          }
        }
      })
    }
    entity.entityProperties = {}
    entity.entityProperties.symbology = {}
    entity.entityProperties.symbology.material =
      entity.polygon.material.color.getValue()
  })
}

function updateSelectByAttributesLayersList(map) {
  /** Update the select by attributes layer list */
  const selectByAttributesLayersList = document.getElementById(
    'selectByAttributesLayers'
  )

  if (!selectByAttributesLayersList) return

  while (
    selectByAttributesLayersList.firstChild &&
    selectByAttributesLayersList.removeChild(
      selectByAttributesLayersList.firstChild
    )
  );

  const layerList = []

  map.mapProperties.layers.vector.forEach(layer => {
    layerList.push(layer.layerProperties.name)
  })

  if (layerList.length === 0) return

  /** Add a disabled option */
  const newOption = document.createElement('option')
  newOption.value = 'selectLayerText'
  newOption.innerText = 'Choose a layer'
  newOption.selected = true
  newOption.disabled = true
  selectByAttributesLayersList.appendChild(newOption)

  layerList.forEach(layerName => {
    const newOption = document.createElement('option')
    newOption.value = layerName
    newOption.innerText = layerName
    selectByAttributesLayersList.appendChild(newOption)
  })
}
