import getLayerType from './getLayerType.js'

export default function removeLayer(layer, map) {
  if (!layer || !map) return

  const type = getLayerType(layer)

  switch (type) {
    case 'vector':
      map.dataSources.remove(layer)
      break
    case 'imagery':
      map.imageryLayers.remove(layer)
      break
  }
}
