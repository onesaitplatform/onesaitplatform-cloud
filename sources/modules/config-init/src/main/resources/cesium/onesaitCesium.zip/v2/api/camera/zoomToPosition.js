/**
 * @classdesc
 * Control the camera behaviour, with the posibility of use of a smooth translation
 * or direct one.
 *
 * Input position coordinates and height is mandatory, while heading, pitch and
 * roll are optional.
 *
 * @param {Object} inputConfig - The values of the camera ending position
 * @param {array} inputConfig.coordinates - The longitude and latitude values
 * @param {number} inputConfig.height - The height of the camera from the geoid
 * @param {number} inputConfig.heading - The orientation of the camera from North
 * @param {number} inputConfig.pitch - The angle of the camera from the horizont
 * @param {number} inputConfig.roll - The angle of the camera from itself
 * @param {number} inputConfig.animated - If true, the camera will move smooth to destination
 * @param {Object} map - The map viewer
 * @returns
 */
export default function zoomToPosition(inputConfig, map) {
  /** Check if the input config exists */
  if (!map || !inputConfig || !inputConfig.coordinates || !inputConfig.height)
    return

  /** Set the variables of the camera output */
  const coordinates = inputConfig.coordinates
  const height = inputConfig.height
  const heading = inputConfig.heading ? inputConfig.heading : 0
  const pitch = inputConfig.pitch
    ? Cesium.Math.toRadians(inputConfig.pitch)
    : Cesium.Math.toRadians(-90)
  const roll = inputConfig.roll ? inputConfig.roll : 0
  const action = inputConfig.animated ? 'flyTo' : 'setView'

  /** Move the camera to the position with the flyTo effect */
  map.camera[action]({
    destination: Cesium.Cartesian3.fromDegrees(
      coordinates[0],
      coordinates[1],
      height
    ),
    orientation: {
      heading: heading,
      pitch: pitch,
      roll: roll
    }
  })
}
