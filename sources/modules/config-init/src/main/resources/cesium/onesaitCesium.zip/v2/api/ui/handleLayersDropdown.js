import getLayersByAttribute from '../search/getLayersByAttribute.js'

export default function handleLayersDropdown(map) {
  /** Handle the layers dropdown behaviour */
  window.onclick = event => {
    if (event.target.parentElement.className === 'layerItem') {
      const div = event.target.parentElement
      const check = div.getElementsByClassName('layerCheck')[0]

      /** Get the ID of the layer */
      const layerId = event.target.parentElement.id

      /** Find the layer by it ID */
      const candidateLayer = getLayersByAttribute('id', layerId, map)

      /** Check if at least one layer is found */
      if (candidateLayer.length > 0) {
        /** Get only the first layer, just in case */
        const layer = candidateLayer[0]

        /** Change the visibility of the layer inverting it */
        layer.show = !layer.show

        /** Show or hide the checkmark */
        check.classList.toggle('hideCheck')
      }
    }
  }
}
