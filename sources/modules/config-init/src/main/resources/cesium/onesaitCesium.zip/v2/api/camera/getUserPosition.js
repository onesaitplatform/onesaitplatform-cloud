import zoomToPosition from './zoomToPosition.js'

export default function getUserPosition(map) {
  if (!map) return

  /** Check if the little man is still on map */
  if (
    map.entities.values.length > 0 &&
    map.entities.values.find(x => x.name === 'userPosition')
  )
    return

  function zoomToUser(position) {
    const coordinates = Cesium.Cartesian3.fromDegrees(
      position.coords.longitude,
      position.coords.latitude
    )

    const billboard =
      ' data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAOiSURBVHhe7dppqA1hHMfxa3lhzVpEsmTJviQURRJCEdmlJEQUkheWrEWKsoc3yJpd2UIoa4mEyBJZCtn3JfH9aZ6anp6551x0zpk5z68+3blzj3Pn/5jzbHMLfHx8fHx8fHx8fHwynTaYjIWYgEbIi1TCDvyyfMcKlERiUxaXYRcfth+JzVK4iraNQ+JSEW/hKth2A8WRqHSCq1gX9Qe1kKh0h6vYKA2RqKggV6EuL1AOicsFuAq2bUAi0wRv4CrauI/ySGQG4jlchRu30RWJyyq4Co4yDYnJDLiKTKU/Yp860LjuKjCVJyiDWGc2VMwz7A2OC/MTO/El+F79RqxzBCpkEyYFx6mo6HPBsVaIsc5FqJA5GB8cp9IL24JjfY11zORHDaCNj3ChUfpga3Csr7GOaYC5KEoDmDvANwBinbxvAG1uqJDFSLcT7I0DwXHst8i6YSgaYzrsYl0GoD307zogMdFI4CrYNgSJiDY1dAfMx2HYK8EH0ITnfeicPMRuaEHUDrHbH2yLNXiMcGE29QmKmfVFuYl5qIecTn1oHm8XcAsbg6/h8xOh2DtFJ3EGH0Ln5BOWoypyLsMQ3va+C936egRmbuFdCBektYFiN4CGQaUG9L4aCX7A/PwReiBnMhrm4p5CDzZKwc5BmNdJVAOo97fTFFpQhV83GFlPS2gJqwvSyq8aovIvDWDSF++g1+muaIWsZh90MerlU+V/NIDSDGZz9ZROZCNLoKe8X6ELUaeljk5TWGkNO4cQLjSqAUbAjvqFtVgN/e7wCKONFk2Z1WdkLOY2jDIIdsz83ohqgJ6wk86magtkLOtwDGbr6hp0ix+Fzmsqa6czwhc8FcoVmHNaO5SGHXWs2lxRY51A+D/gOPR7s/I8UQ2hi9BHIJ1ou+sqNCscrhNEt7D2DNWf1NaJFFHjmgZQY2c1NfEKupjT0C5wOgk//dFfhaT7NEgNaOYb2m3O6G0flS74CF2UeueZKGw4/Jt0hBlxRENvTu0Ya/5/HeYCdVdoVOiHqMYYAz00cY0YJdAcU3AW5n3lHnLy8Zlmf7Ogz3P4gvV5PY/1UEFa76uAz9DPN0OrxlFYAPUJdxB+D1GjLkIF5HSqQNtf6hi/wS6kKDTbU8+vEaM6Ype60MxuGdRj6+nvS5gJlKGGeg0torQaXImRaIBEpRj0B1Mas/dAxWt81/BXGfrs5022Qw1w6c93eZix2AKNBD4+Pj4+Pj4+PplLQcFv+LInEMx66yEAAAAASUVORK5CYII='

    const userPoint = map.entities.add({
      name: 'userPosition',
      position: coordinates,
      billboard: {
        image: billboard,
        heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
        disableDepthTestDistance: Number.POSITIVE_INFINITY
      }
    })

    const zoomConfig = {
      coordinates: [position.coords.longitude, position.coords.latitude],
      height: 1000,
      animated: true
    }

    setTimeout(() => {
      zoomToPosition(zoomConfig, map)
      setTimeout(() => vanishAction(userPoint, map), 5000)
    }, 500)
  }

  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(zoomToUser)
  } else {
    console.warn('Geolocation is not supported by this browser.')
  }
}

function vanishAction(entity, map) {
  let alpha = 1
  const interval = setInterval(vanishing, 100)

  function vanishing() {
    alpha -= 0.05
    entity.billboard.color = new Cesium.Color(1.0, 1.0, 1.0, alpha)
    if (alpha <= 0.05) {
      clearInterval(interval)
      map.entities.remove(entity)
    }
  }
}
