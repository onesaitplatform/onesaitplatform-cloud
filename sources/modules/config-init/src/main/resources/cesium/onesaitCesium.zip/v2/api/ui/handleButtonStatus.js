export default function handleButtonStatus(button) {
  if (!button) return

  /** Change the button status */
  button.pushed = button.autoSwitch ? false : !button.pushed

  /** Get the button element by it ID */
  const buttonDiv = document.getElementById(button.id)

  /** Check if is pushed or unspushed and change the button color using classes */
  if (button.pushed) {
    const newStyle = buttonDiv.className.replace('button', 'buttonActive')
    buttonDiv.className = newStyle
  } else {
    const newStyle = buttonDiv.className.replace('buttonActive', 'button')
    buttonDiv.className = newStyle
  }
}
