import calculateArea from '../gp/calculateArea.js'
import handleButtonStatus from '../ui/handleButtonStatus.js'
import restoreButtonsStatus from '../ui/restoreButtonsStatus.js'

export default function measureArea(map) {
  if (!map) return

  /** Handle the button status */
  const button = map.mapProperties.buttonsToolbar.find(
    x => x.id === 'measureArea'
  )

  /** Make sure the button exists */
  if (!button) return

  /** Switch off the buttons */
  restoreButtonsStatus(button, map)
  removeHandlers(map)

  /** Change the behaviour of the button */
  handleButtonStatus(button, map)

  /** Check if the button is ON or OFF */
  button.pushed ? initMeasureArea(map) : endMeasureArea(map)
}

function initMeasureArea(map) {
  /** Disable map selection */
  map.mapProperties.selection.enabled = false

  /** Clear any measure entity of the map */
  removeEntities(map)

  /** Change the cursor icon, to show the user is drawing */
  document.body.style.cursor = 'copy'

  /** Set the symbology to use */
  const symbology = {
    point: Cesium.Color.RED.withAlpha(0.6),
    linestring: Cesium.Color.DARKORANGE.withAlpha(0.6),
    polygon: Cesium.Color.DARKORANGE.withAlpha(0.6)
  }

  /** Set some useful variables */
  let activePoints = []
  let measureEntity
  let floatingPoint

  /*************/
  /** HANDLERS */
  /*************/

  /** Create a map handler for the drawing ruler */
  const handler = new Cesium.ScreenSpaceEventHandler(map.canvas)
  handler.config = {}
  handler.config.id = 'measureArea'

  /** Add the handler to the map handler list */
  map.mapProperties.handlers.push(handler)

  /** Listen for NEW POINTS */
  handler.setInputAction(event => {
    /** Get the coordinates of the click */
    let position = map.scene.pickPosition(event.position)

    /** Do this in case the user clicks over an entity */
    if (!position) {
      position = map.camera.pickEllipsoid(
        event.position,
        map.scene.globe.ellipsoid
      )
    }

    /** Check if the user has clicked INSIDE the map viewer */
    if (Cesium.defined(position)) {
      /** Check if active points is just one, to make a linestring */
      if (activePoints.length === 0) {
        /** Remove any previous measure entities (clean the map) */
        removeEntities(map)

        /** Create a point with each user clic */
        floatingPoint = drawPoint(position, symbology.point, map)

        /** Add the position to the list of active points */
        activePoints.push(position)

        /** Get the positions until now */
        const dynamicPositions = new Cesium.CallbackProperty(() => {
          return activePoints
        }, false)

        /** Draw a temporal polygon with this temporal points */
        measureEntity = drawLineString(
          dynamicPositions,
          symbology.linestring,
          map
        )
      } else if (activePoints.length > 1) {
        /** Remove the linestring */
        map.entities.remove(
          map.entities.values.find(x => x.name === 'measureLineString')
        )
        /** Remove previous polygons */
        map.entities.remove(
          map.entities.values.find(x => x.name === 'measurePolygon')
        )

        /** Create a point with each user click */
        floatingPoint = drawPoint(position, symbology.point, map)

        /** Add the position to the list of active points */
        activePoints.push(position)

        /** Get the positions until now */
        const dynamicPositions = new Cesium.CallbackProperty(() => {
          return new Cesium.PolygonHierarchy(activePoints)
        }, false)

        /** Draw a temporal polygon with this temporal points */
        measureEntity = drawPolygon(
          dynamicPositions,
          symbology.polygon,
          false,
          map
        )
      }

      /** Se van añadiendo al listado las posiciones de los puntos generados */
      activePoints.push(position)

      /** Y se van creando puntos */
      drawPoint(position, symbology.point, map)
    }
  }, Cesium.ScreenSpaceEventType.LEFT_CLICK)

  /** Listen for RESIZING */
  handler.setInputAction(event => {
    /** Check if the floating point exists */
    if (Cesium.defined(floatingPoint)) {
      /** Set the current mouse position as the new position every moment */
      const newPosition = map.scene.pickPosition(event.endPosition)

      /** Check if the user has clicked INSIDE the map viewer */
      if (Cesium.defined(newPosition)) {
        /** Update the floating point position */
        floatingPoint.position.setValue(newPosition)
        activePoints.pop()
        activePoints.push(newPosition)
      }

      if (activePoints.length > 3) {
        /** Get the polygon */
        const polygon = map.entities.values.find(
          x => x.name === 'measurePolygon'
        )

        /** Get the label */
        let label = map.entities.values.find(x => x.name === 'measureLabel')

        /** Get it coordinates */
        const cartesianCoordinates =
          polygon.polygon.hierarchy.getValue().positions

        /** Calculate the area and the centroid coords */
        let area = calculateArea(cartesianCoordinates).toFixed(4)
        let units = ' m2'

        if (area > 1000000) {
          area = (area / 1000000).toFixed(4)
          units = ' km2'
        }

        const centroid =
          Cesium.BoundingSphere.fromPoints(cartesianCoordinates).center

        /** If the label doesn't exists, create it */
        if (!label) {
          label = drawLabel(centroid, area, map)
        }

        /** Update the label with the area value over the centroid */
        label.position.setValue(centroid)
        label.label.text.setValue(area + units)
      }
    }
  }, Cesium.ScreenSpaceEventType.MOUSE_MOVE)

  /** Listeng for END DRAWING */
  handler.setInputAction(() => {
    /** Remove the floating point */
    activePoints.pop()

    /** Check if are, at least, three points to create a polygon */
    if (activePoints.length > 3) {
      /** Draw the final area polygon */
      const polygon = drawPolygon(activePoints, symbology.polygon, true, map)

      /** Draw the final label */
      map.entities.remove(
        map.entities.values.find(x => x.name === 'measureLabel')
      )

      /** Get the coordinates of the polygon, the area and the centroid */
      const cartesianCoordinates =
        polygon.polygon.hierarchy.getValue().positions
      const area = calculateArea(cartesianCoordinates).toFixed(4)

      const centroid =
        Cesium.BoundingSphere.fromPoints(cartesianCoordinates).center

      /** Generate the label */
      drawLabel(centroid, area, map)
    } else {
      removeEntities(map)
    }

    /** Some cleaning */
    map.entities.remove(floatingPoint)
    map.entities.remove(measureEntity)
    floatingPoint = undefined
    measureEntity = undefined
    activePoints = []
  }, Cesium.ScreenSpaceEventType.RIGHT_CLICK)
}

function endMeasureArea(map) {
  /** Enable map selection */
  map.mapProperties.selection.enabled = true

  /** Remove all measure entities */
  removeEntities(map)

  /** Get the handler */
  const handler = map.mapProperties.handlers.find(
    x => x.config.id === 'measureArea'
  )

  if (handler) handler.destroy()

  /** Remove all handlers from the map viewer list */
  map.mapProperties.handlers.length = 0

  /** Reset the cursor style */
  document.body.style.cursor = 'auto'
}

function removeEntities(map) {
  map.entities.values
    .filter(entity => entity.name && entity.name.includes('measure'))
    .forEach(entity => map.entities.remove(entity))
}

function drawPoint(coordinates, symbology, map) {
  /** Create the point and add it to the map */
  const point = map.entities.add({
    name: 'measurePoint',
    position: coordinates,
    point: {
      color: symbology,
      heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
      pixelSize: 10
    }
  })

  /** Return the point to store it as a temporal entity */
  return point
}

function drawLineString(coordinates, symbology, map) {
  const lineString = map.entities.add({
    name: 'measureLineString',
    polyline: {
      positions: coordinates,
      clampToGround: true,
      material: new Cesium.PolylineDashMaterialProperty({
        color: symbology,
        dashLength: 12.0
      }),
      width: 3
    }
  })

  /** Se devuelve la polilínea */
  return lineString
}

function drawPolygon(coordinates, symbology, end, map) {
  const polygon = map.entities.add({
    name: end ? 'measurePolygonFinal' : 'measurePolygon',
    polygon: {
      hierarchy: coordinates,
      material: new Cesium.ColorMaterialProperty(symbology)
    }
  })

  return polygon
}

function drawLabel(centroid, areaValue, map) {
  let units = ' m2'

  if (areaValue > 1000000) {
    areaValue = (areaValue / 1000000).toFixed(4)
    units = ' km2'
  }

  const label = map.entities.add({
    name: 'measureLabel',
    position: centroid,
    label: {
      text: areaValue + units,
      style: Cesium.LabelStyle.FILL_AND_OUTLINE,
      outlineWidth: 2,
      font: '16px sans-serif',
      pixelOffset: new Cesium.Cartesian2(0.0, -20),
      showBackground: true,
      heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
      disableDepthTestDistance: Number.POSITIVE_INFINITY
    }
  })

  return label
}

function removeHandlers(map) {
  if (map.mapProperties.handlers.length > 0) {
    map.mapProperties.handlers
      .filter(handler => handler.config.id.includes('measure'))
      .forEach(handler => {
        handler.destroy()
      })
  }

  map.mapProperties.handlers = map.mapProperties.handlers.filter(
    handler => !handler.config.id.includes('measure')
  )
}
