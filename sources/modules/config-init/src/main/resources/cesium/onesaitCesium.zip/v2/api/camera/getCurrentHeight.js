export default function getCurrentHeight(map) {
  if (!map) return

  /** Get camera position and ellopsoid */
  const cameraPosition = map.scene.camera.positionWC
  const ellipsoid =
    map.scene.globe.ellipsoid.scaleToGeodeticSurface(cameraPosition)

  /** Return the height */
  return Cesium.Cartesian3.magnitude(
    Cesium.Cartesian3.subtract(
      cameraPosition,
      ellipsoid,
      new Cesium.Cartesian3()
    )
  ).toFixed()
}
