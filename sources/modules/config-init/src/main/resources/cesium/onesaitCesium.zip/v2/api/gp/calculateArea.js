export default function calculateArea(cartesianCoords) {
  if (!cartesianCoords) return

  /** Set an array to store the coordinates in degrees */
  const coordinatesArray = []

  /** Transform the cartesian values to degrees */
  cartesianCoords.forEach(cartesian => {
    const coordinates = Cesium.Cartographic.fromCartesian(cartesian)
    coordinatesArray.push([
      (coordinates.longitude / Math.PI) * 180,
      (coordinates.latitude / Math.PI) * 180
    ])
  })

  /** Add the first coordinate as the closing one, 'cause a polygon */
  coordinatesArray.push(coordinatesArray[0])

  /** Use Turf to construct a polygon and calculate it area */
  const turfPolygon = turf.polygon([coordinatesArray])

  /** Return the calculated area */
  return turf.area(turfPolygon)
}
