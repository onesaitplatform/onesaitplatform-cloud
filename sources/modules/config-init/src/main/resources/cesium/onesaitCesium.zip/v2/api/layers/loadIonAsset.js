import updateLayersDropdown from '../ui/updateLayersDropdown.js'

export default function loadIonAsset(inputConfig, map) {
  if (!map || !inputConfig || !inputConfig.code || !inputConfig.id) return

  /** Set the params */
  const code = inputConfig.code
  const id = inputConfig.id
  const name = inputConfig.name ? inputConfig.name : inputConfig.id

  /** Create the layer */
  const layer = map.scene.primitives.add(
    new Cesium.Cesium3DTileset({
      url: Cesium.IonResource.fromAssetId(code)
    })
  )

  /** Add the layer properties */
  layer.layerProperties = {}
  layer.layerProperties.id = id
  layer.layerProperties.name = name
  layer.layerProperties.type = 'assetIon'

  /** Add the layer to the map and the map list */
  map.mapProperties.layers.assets.push(layer)

  /** Add the layer to the layers dropdown */
  updateLayersDropdown({
    id: id,
    name: name,
    type: 'assetIon'
  })
}
