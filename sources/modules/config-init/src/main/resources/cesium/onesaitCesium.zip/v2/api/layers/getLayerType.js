export default function getLayerType(layer) {
  if (!layer || !layer.hasOwnProperty('layerProperties')) return

  return layer.layerProperties.type
}
