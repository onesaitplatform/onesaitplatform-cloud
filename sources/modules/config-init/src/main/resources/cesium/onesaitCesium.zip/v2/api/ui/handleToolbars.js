import changeZoom from '../camera/changeZoom.js'
import cursorCoordinates from '../measure/cursorCoordinates.js'
import getUserPosition from '../camera/getUserPosition.js'
import handleLegend from './handleLegend.js'
import measureDistance from '../measure/measureDistance.js'
import measureArea from '../measure/measureArea.js'
import selectByAttributes from '../selection/selectByAttributes.js'
import zoomToPosition from '../camera/zoomToPosition.js'

export default function handleToolbars(map) {
  if (!map) return

  /** Get the toolbars buttons */
  const buttons = document.getElementsByClassName('button')

  /** Listen for clicked button */
  Object.values(buttons).forEach(button => {
    button.onclick = btn => launchAction(btn.target.id, map)
  })
}

function launchAction(id, map) {
  if (!id) return

  /** Check which button has been pushed */
  switch (id) {
    /** TOOLBAR ZOOM */
    case 'zoomPlus':
      changeZoom('plus', map)
      break
    case 'home':
      zoomToPosition(map.mapProperties.homeView, map)
      break
    case 'zoomMinus':
      changeZoom('minus', map)
      break

    /** TOOLBAR UTILITIES */

    case 'measureDistance':
      measureDistance(map)
      break
    case 'measureArea':
      measureArea(map)
      break
    case 'userPosition':
      getUserPosition(map)
      break
    case 'cursorCoordinates':
      cursorCoordinates(map)
      break
    case 'selectByAttributes':
      selectByAttributes(map)
      break

    /** LAYERS DROPDOWN */
    case 'showLayers':
      handleLegend(map)
      break

    default:
      break
  }
}
