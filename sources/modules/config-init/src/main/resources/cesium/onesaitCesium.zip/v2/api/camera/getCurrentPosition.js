export default function getCurrentPosition(map) {
  if (!map) return

  const windowPosition = new Cesium.Cartesian2(
    map.container.clientWidth / 2,
    map.container.clientHeight / 2
  )
  const pickRay = map.scene.camera.getPickRay(windowPosition)
  const pickPosition = map.scene.globe.pick(pickRay, map.scene)
  const pickPositionCartographic =
    map.scene.globe.ellipsoid.cartesianToCartographic(pickPosition)
  const longitude = pickPositionCartographic.longitude * (180 / Math.PI)
  const latitude = pickPositionCartographic.latitude * (180 / Math.PI)

  return [longitude, latitude]
}
