export default function loadBasemap(inputConfig, map) {
  if (!inputConfig || !map) return

  const url = inputConfig.url
  const id = inputConfig.id
  const name = inputConfig.name
  const type = inputConfig.type
  const unique = inputConfig.unique

  /** Check if will be just one basemap allowed */
  if (unique) {
    /** Remove all previous basemaps */
    map.imageryLayers._layers
      .filter(x => x.isBaseLayer())
      .forEach(basemap => {
        map.imageryLayers.remove(basemap)
      })
    map.mapProperties.layers.basemaps.length = 0
  }

  let provider = undefined

  switch (type) {
    case 'esri':
      provider = 'ArcGisMapServerImageryProvider'
      break

    case 'osm':
      provider = 'OpenStreetMapImageryProvider'
      break
  }

  if (!provider) return

  const basemap = map.imageryLayers.addImageryProvider(
    new Cesium[provider]({
      url: type === 'osm' ? 'https://a.tile.openstreetmap.org/' : url
    })
  )

  map.mapProperties.layers.basemaps.push(basemap)
}
