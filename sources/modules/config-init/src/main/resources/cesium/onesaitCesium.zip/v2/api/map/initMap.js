import handleGeocoder from '../geocoder/handleGeocoder.js'
import handleLayersDropdown from '../ui/handleLayersDropdown.js'
import handleEntitySelection from '../selection/handleEntitySelection.js'
import handleEntityPopupPosition from '../popup/handleEntityPopupPosition.js'
import handleToolbars from '../ui/handleToolbars.js'
import zoomToPosition from '../camera/zoomToPosition.js'

/**
 * @classdesc
 * Create the map viewer, modify its initial properties, and generate the confi-
 * guration objects to use with the API. Also, it launchs the differents events
 * listener of the map viewer (selection, popup, geocoder, etc.).
 *
 * The API Token is for use only with the Onesait Platform Map Viewer, so if you
 * want an API token, please register on Cesium Ion and get your own (is FREE,
 * so please...).
 *
 * @returns The map viewer
 */
export default function initMap() {
  /** Set the viewer default properties */
  const mapConfig = {
    animation: false,
    baseLayerPicker: false,
    fullscreenButton: false,
    vrButton: false,
    geocoder: false,
    homeButton: false,
    infoBox: false,
    // imageryProvider: new Cesium.OpenStreetMapImageryProvider({
    //   url: 'https://a.tile.openstreetmap.org/'
    // }),
    sceneModePicker: false,
    selectionIndicator: false,
    terrainProvider: Cesium.createWorldTerrain(),
    timeline: false,
    navigationHelpButton: false,
    navigationInstructionsInitiallyVisible: false,
    // mapProjection: new Cesium.WebMercatorProjection(),
    scene3DOnly: true,
    sceneMode: Cesium.SceneMode.SCENE3D,
    shouldAnimate: false
  }

  /** Set the default map view */
  const mapView = {
    coordinates: [-3.0, 39.8],
    height: 1900000
  }

  /** Set the viewer access token */
  Cesium.Ion.defaultAccessToken =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI2Y2ZkMTQ0OS1lOWEwLTQ5ZGEtOTA0ZC00OTlmMzhjYmFjZTEiLCJpZCI6NTg1MSwiaWF0IjoxNjQ2OTE1MDYyfQ.IBxbaZ-JQK6pwNipaS_T3lX4rWRqDKZ3ppxYlxzfJxc'

  /** Create the map viewer */
  const map = new Cesium.Viewer('cesiumContainer', mapConfig)

  map.scene.globe.depthTestAgainstTerrain = true

  /** Disable the double click behaviour */
  map.screenSpaceEventHandler.removeInputAction(
    Cesium.ScreenSpaceEventType.LEFT_DOUBLE_CLICK
  )

  /** Set the map view, by default over the Iberian Peninsula */
  zoomToPosition(mapView, map)

  /** Set map properties */
  map.mapProperties = {}

  map.mapProperties.vendors = {
    cesium: '1.9.2',
    CesiumHeatmap: '0.1',
    heatmap: '2.0.0',
    onesaitCesium: '2.0.0',
    turf: '6.5.0'
  }

  map.mapProperties.homeView = {
    coordinates: mapView.coordinates,
    height: mapView.height,
    animated: true
  }

  /** Set the map properties content */
  map.mapProperties.layers = {}
  map.mapProperties.layers.assets = []
  map.mapProperties.layers.basemaps = []
  map.mapProperties.layers.heatmaps = []
  map.mapProperties.layers.imagery = []
  map.mapProperties.layers.vector = []
  map.mapProperties.layers.wms = []

  map.mapProperties.buttonsToolbar = []

  map.mapProperties.handlers = []
  map.mapProperties.entityCollections = []

  map.mapProperties.popup = {
    position: undefined,
    opened: false
  }

  map.mapProperties.selection = {}
  map.mapProperties.selection.enabled = true
  map.mapProperties.selection.selectedEntity = undefined

  /** Add the default basemap to the layer list */
  map.mapProperties.layers.basemaps.push(map.imageryLayers._layers[0])

  /** Get all the buttons of the map and add them to the buttons toolbar */
  const buttons = document.getElementsByClassName('button')

  /** Get all buttons and its properties */
  Object.values(buttons).forEach(button => {
    const buttonId = button.id
    const autoSwitch =
      button.getAttribute('data-autoSwitch') === 'true' ? true : false
    const standAlone =
      button.getAttribute('data-standAlone') === 'true' ? true : false

    map.mapProperties.buttonsToolbar.push({
      id: buttonId,
      pushed: false,
      autoSwitch: autoSwitch,
      standAlone: standAlone,
      disabled: false
    })
  })

  /** LISTENERS */
  handleToolbars(map)
  handleEntitySelection(map)
  handleLayersDropdown(map)
  handleEntityPopupPosition(map)
  handleGeocoder(map)

  return map
}
