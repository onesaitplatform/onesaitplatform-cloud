import updateLayersDropdown from '../ui/updateLayersDropdown.js'

export default function loadWms(inputConfig, map) {
  if (
    !map ||
    !inputConfig ||
    !inputConfig.url ||
    !inputConfig.id ||
    !inputConfig.layers
  )
    return

  /** Set the params */
  const url = inputConfig.url
  const id = inputConfig.id
  const name = inputConfig.name ? inputConfig.name : inputConfig.id
  const layers = inputConfig.layers ? [inputConfig.layers] : []

  /** Create the layer */
  const layer = map.imageryLayers.addImageryProvider(
    new Cesium.WebMapServiceImageryProvider({
      url: url,
      layers: layers,
      // proxy: new Cesium.DefaultProxy('/proxy/'),
      parameters: {
        transparent: true,
        format: 'image/png'
      }
    })
  )

  /** Add the layer properties */
  layer.layerProperties = {}
  layer.layerProperties.id = id
  layer.layerProperties.name = name
  layer.layerProperties.type = 'wms'

  /** Add the layer to the map and the map list */
  // map.imageryLayers.addImageryProvider(layer)
  map.mapProperties.layers.wms.push(layer)

  /** Add the layer to the layers dropdown */
  updateLayersDropdown({
    id: id,
    name: name,
    type: 'wms'
  })
}
