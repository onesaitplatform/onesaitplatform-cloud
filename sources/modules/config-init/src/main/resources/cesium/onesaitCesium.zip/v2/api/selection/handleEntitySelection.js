import {
  selectEntity,
  unselectEntity
} from '../selection/changeSelectionSymbology.js'
import getEntityGeometry from './getEntityGeometry.js'
import handleEntityPopup from '../popup/handleEntityPopup.js'

export default function handleEntitySelection(map) {
  if (!map) return

  const handler = new Cesium.ScreenSpaceEventHandler(map.scene.canvas)
  handler.config = {}
  handler.config.id = 'selectEntity'

  /** Add the handler to the map handler list */
  map.mapProperties.handlers.push(handler)

  handler.setInputAction(click => {
    /** Check if there is a selected entity */
    if (
      Cesium.defined(map.selectedEntity) &&
      getEntityGeometry(map.selectedEntity) &&
      map.mapProperties.selection.enabled
    ) {
      const selectedEntity = map.selectedEntity

      /** Get the position of the click, or the point centroid */
      let clickedCoordinates = map.scene.pickPosition(click.position)
      if (!clickedCoordinates) {
        clickedCoordinates = selectedEntity.position.getValue()
      }

      /** Check if there is not a previous selection */
      if (!map.mapProperties.selection.selectedEntity) {
        map.mapProperties.selection.selectedEntity = selectedEntity
        selectEntity(selectedEntity)

        /** Open the popup */
        handleEntityPopup(map, selectedEntity, clickedCoordinates)
      } else {
        const selectedEntityId = selectedEntity.id
        const currentSelectedEntityId =
          map.mapProperties.selection.selectedEntity.id
        if (selectedEntityId === currentSelectedEntityId) {
          map.mapProperties.selection.selectedEntity = undefined
          unselectEntity(selectedEntity)

          /** Close the popup */
          handleEntityPopup(map)
        } else {
          unselectEntity(map.mapProperties.selection.selectedEntity)
          map.mapProperties.selection.selectedEntity = selectedEntity
          selectEntity(selectedEntity)

          /** Open the popup */
          handleEntityPopup(map, selectedEntity, clickedCoordinates)
        }
      }
    } else {
      if (map.mapProperties.selection.selectedEntity) {
        unselectEntity(map.mapProperties.selection.selectedEntity)
        map.mapProperties.selection.selectedEntity = undefined

        /** Close the popup */
        handleEntityPopup(map)
      }
    }
  }, Cesium.ScreenSpaceEventType.LEFT_CLICK)
}
