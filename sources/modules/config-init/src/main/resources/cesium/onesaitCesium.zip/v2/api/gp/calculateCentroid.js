import getEntityGeometry from '../selection/getEntityGeometry.js'

export default function calculateCentroid(entity) {
  if (!entity) return

  const geometry = getEntityGeometry(entity)

  let centroid = undefined
  let positions = undefined

  switch (geometry) {
    case 'point':
      centroid = entity.position.getValue()
      break

    case 'polyline':
      positions = [...entity.polyline.positions.getValue()]
      positions.push(position[position.length - 1])
      centroid = Cesium.BoundingSphere.fromPoints(positions).center
      break

    case 'polygon':
      positions = entity.polygon.hierarchy.getValue().positions
      centroid = Cesium.BoundingSphere.fromPoints(positions).center
      break
  }

  return centroid
}
