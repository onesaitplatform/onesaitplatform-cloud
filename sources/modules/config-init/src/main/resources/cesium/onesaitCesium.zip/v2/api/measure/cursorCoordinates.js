import handleButtonStatus from '../ui/handleButtonStatus.js'
import removeHandler from '../map/removeHandler.js'

export default function cursorCoordinates(map) {
  if (!map) return

  /** Handle the button status */
  const button = map.mapProperties.buttonsToolbar.find(
    x => x.id === 'cursorCoordinates'
  )

  /** Check if the button has been found */
  if (!button) return

  /** Change the status and color of the button */
  handleButtonStatus(button, map)

  /** Check if the button is ON or OFF */
  button.pushed ? initCursorCoordinates(map) : endCursorCoordinates(button, map)
}

function initCursorCoordinates(map) {
  /** Set a handler to get the mouse position */
  const handler = new Cesium.ScreenSpaceEventHandler(map.scene.canvas)
  handler.config = {}
  handler.config.id = 'cursorCoordinates'

  /** Add the handler to the map handler list */
  map.mapProperties.handlers.push(handler)

  /** Create an entity to show the coordinates over the map */
  const entity = map.entities.add({
    name: 'cursorPosition',
    label: {
      show: false,
      showBackground: true,
      font: '14px monospace',
      horizontalOrigin: Cesium.HorizontalOrigin.LEFT,
      verticalOrigin: Cesium.VerticalOrigin.TOP,
      pixelOffset: new Cesium.Cartesian2(25, 0),
      heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
      disableDepthTestDistance: Number.POSITIVE_INFINITY
    }
  })

  /** Listen the mouse movement */
  handler.setInputAction(movement => {
    /** Get the cartesian position of the mouse */
    const cartesian = map.camera.pickEllipsoid(
      movement.endPosition,
      map.scene.globe.ellipsoid
    )

    /** If the mouse is inside the map (not aiming the space, for example) */
    if (cartesian) {
      /** Change the cursos style */
      document.body.style.cursor = 'help'

      /** Transform the cartesian position to a cartographic position */
      const cartographic = Cesium.Cartographic.fromCartesian(cartesian)

      /** Get the longitude and latitude */
      const longitude = Cesium.Math.toDegrees(cartographic.longitude).toFixed(2)
      const latitude = Cesium.Math.toDegrees(cartographic.latitude).toFixed(2)

      /** Change the entity properties */
      entity.position = cartesian
      entity.label.show = true

      const longitudeGap = longitude < 0 ? ' ' : '  '
      const latitudeGag = latitude < 0 ? '  ' : '   '

      /** Set the panel information */
      entity.label.text =
        'Longitude:' +
        longitudeGap +
        longitude +
        '\u00B0' +
        '\n' +
        'Latitude:' +
        latitudeGag +
        latitude +
        '\u00B0'
    } else {
      /** Restore the cursor style */
      document.body.style.cursor = 'auto'
    }
  }, Cesium.ScreenSpaceEventType.MOUSE_MOVE)
}

function endCursorCoordinates(button, map) {
  /** Destroy the measure distance handlers */
  removeHandler(map, button.id)

  /** Reset the cursor symbol */
  document.body.style.cursor = 'auto'

  /** Remove the entity */
  map.entities.remove(
    map.entities.values.find(x => x.name === 'cursorPosition')
  )
}
