import handleButtonStatus from '../ui/handleButtonStatus.js'
import restoreButtonsStatus from '../ui/restoreButtonsStatus.js'

export default function measureDistance(map) {
  if (!map) return

  /** Handle the button status */
  const button = map.mapProperties.buttonsToolbar.find(
    x => x.id === 'measureDistance'
  )

  if (!button) return

  /** Switch off the buttons */
  restoreButtonsStatus(button, map)
  removeHandlers(map)

  /** Change the behaviour of the button */
  handleButtonStatus(button, map)

  /** Check if the button is ON or OFF */
  button.pushed
    ? initMeasureDistance(button, map)
    : endMeasureDistance(button, map)
}

function initMeasureDistance(button, map) {
  /** Disable map selection */
  map.mapProperties.selection.enabled = false

  /** Clear any measure entity of the map */
  removeEntities(map)

  /** Create a map handler for the drawing ruler */
  const handler = new Cesium.ScreenSpaceEventHandler(map.canvas)
  handler.config = {}
  handler.config.id = 'measureDistance'

  /** Add the handler to the map handler list */
  map.mapProperties.handlers.push(handler)

  /** Set the symbology to use for the ruler labels */
  const symbology = {
    point: Cesium.Color.RED.withAlpha(0.6),
    linestring: Cesium.Color.DARKORANGE.withAlpha(0.6)
  }

  let activeShapePoints = []
  let activeShape
  let floatingPoint
  let counter = 0

  /** Change the cursor icon, to show the user is drawing */
  document.body.style.cursor = 'copy'

  /** Draw a point */
  function createPoint(coordinates) {
    let point = map.entities.add({
      name: 'measurePoint',
      position: coordinates,
      point: {
        color: symbology.point,
        heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
        pixelSize: 10
      }
    })

    /** Se devuelve el punto, para almacenarlo como punto temporal */
    return point
  }

  /** Función que dibuja la polilínea */
  function drawShapePolyline(positionData) {
    /** Se define una variable con la forma de la entidad */
    let shape

    /** Se genera la entidad de la polilínea */
    shape = map.entities.add({
      name: 'measurePolyline',
      polyline: {
        positions: positionData,
        clampToGround: true,
        material: new Cesium.PolylineDashMaterialProperty({
          color: symbology.linestring,
          dashLength: 12.0
        }),
        width: 3
      }
    })

    /** Se devuelve la polilínea */
    return shape
  }

  /** Función que calcula la longitud de la polilínea */
  function polylineLength(polyline) {
    /** Se definen los puntos iniciales y finales de la polilínea */
    let initialPosition = polyline.polyline.positions.getValue()[0]
    let finalPosition =
      polyline.polyline.positions.getValue()[
        polyline.polyline.positions.getValue().length - 1
      ]

    /** Se genera el elipsoide geodésico a partir de las coordenadas */
    let ellipsoidGeodesic = new Cesium.EllipsoidGeodesic(
      Cesium.Ellipsoid.WGS84.cartesianToCartographic(initialPosition),
      Cesium.Ellipsoid.WGS84.cartesianToCartographic(finalPosition)
    )

    let midPoint = ellipsoidGeodesic.interpolateUsingFraction(0.5)

    /** Se define la etiqueta que aparecerá encima de la regla */
    map.entities.add({
      name: 'measureLabel',
      position: new Cesium.Cartesian3.fromRadians(
        midPoint.longitude,
        midPoint.latitude,
        midPoint.height
      ),
      label: {
        text: (ellipsoidGeodesic.surfaceDistance * 0.001).toFixed(2) + 'km',
        style: Cesium.LabelStyle.FILL_AND_OUTLINE,
        outlineWidth: 2,
        font: '18px sans-serif',
        pixelOffset: new Cesium.Cartesian2(0.0, -20),
        showBackground: true,
        heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
        disableDepthTestDistance: Number.POSITIVE_INFINITY
      }
    })
  }

  /** Función que elimina los puntos de guiado de la guía */
  function clear() {
    map.entities.values.forEach(entity => map.entities.remove(entity))
  }

  handler.setInputAction(event => {
    /** Get the coordinates of the click */
    const position = map.camera.pickEllipsoid(event.position)

    /** Check if the user has clicked INSIDE the map viewer */
    if (Cesium.defined(position)) {
      counter += 1

      /** Se mira si se han definido puntos activos previamente */
      if (activeShapePoints.length === 0) {
        /** Con cada click, se genera un punto en el mapa */
        floatingPoint = createPoint(position)

        /** Se mete en el listado la posición del punto generado */
        activeShapePoints.push(position)

        /** Se define las posiciones hasta el momento */
        let dynamicPositions = new Cesium.CallbackProperty(() => {
          return activeShapePoints
        }, false)

        /** Se va pintando un polígono temporal con los puntos temporales */
        activeShape = drawShapePolyline(dynamicPositions)
      }

      /** Se van añadiendo al listado las posiciones de los puntos generados */
      activeShapePoints.push(position)

      /** Y se van creando puntos */
      createPoint(position)

      /** Se cuenta si hay al menos dos puntos ya pintados */
      if (counter > 1) {
        /** Entonces se lanza la función que mide entre puntos */
        polylineLength(activeShape)

        /** Se destruye la variable que escucha, para que pinte un único punto */
        handler.destroy()

        /** Se limpia */
        // clear()

        /** El ratón regresa al puntero básico */
        document.body.style.cursor = 'auto'

        /** Change the behaviour of the button */
        handleButtonStatus(button, map)
      }
    }
  }, Cesium.ScreenSpaceEventType.LEFT_CLICK)

  /** Se producirá este evento cuando se mueva el cursor por el visor */
  handler.setInputAction(event => {
    /** Se comprueba si el punto flotante es correcto */
    if (Cesium.defined(floatingPoint)) {
      /** Se define una nueva posición (siguinte punto) */
      let newPosition = map.camera.pickEllipsoid(event.endPosition)

      /** Se comprueba si este nuevo punto es válido */
      if (Cesium.defined(newPosition)) {
        /** Se reasignan los valores */
        floatingPoint.position.setValue(newPosition)
        activeShapePoints.pop()
        activeShapePoints.push(newPosition)
      }
    }
  }, Cesium.ScreenSpaceEventType.MOUSE_MOVE)

  /** Cuando el usuario quiera terminar, tocará el botón derecho */
  handler.setInputAction(event => {
    /** Se indica el número de puntos generados hasta el momento */
    counter += 1

    if (counter > 1) {
      /** Se lanza la función que mide entre puntos */
      polylineLength(activeShape)
      // clear()

      /** Change the behaviour of the button */
      handleButtonStatus(button, map)
    }

    /** Se destruye la variable que escucha, para que pinte un único punto */
    handler.destroy()

    /** El ratón regresa al puntero básico */
    document.body.style.cursor = 'auto'
  }, Cesium.ScreenSpaceEventType.RIGHT_CLICK)
}

function endMeasureDistance(button, map) {
  /** Enable map selection */
  map.mapProperties.selection.enabled = true

  /** Destroy the measure distance handlers */
  map.mapProperties.handlers
    .filter(x => (x.config.id = 'measureDistance'))
    .forEach(handler => handler.destroy())

  /** Clear the handlers list */
  map.mapProperties.handlers.length = 0

  removeEntities(map)

  /** Reset the cursor symbol */
  document.body.style.cursor = 'auto'
}

function removeEntities(map) {
  if (map.entities.values.length > 0) {
    map.entities.values
      .filter(entity => entity.name && entity.name.includes('measure'))
      .forEach(entity => map.entities.remove(entity))
  }
}

function removeHandlers(map) {
  if (map.mapProperties.handlers.length > 0) {
    map.mapProperties.handlers
      .filter(handler => handler.config.id.includes('measure'))
      .forEach(handler => {
        handler.destroy()
      })
  }

  map.mapProperties.handlers = map.mapProperties.handlers.filter(
    handler => !handler.config.id.includes('measure')
  )
}
