import handleButtonStatus from '../ui/handleButtonStatus.js'

export default function handleLegend(map) {
  if (!map) return

  if (document.getElementById('layersDropdown').hasChildNodes()) {
    document.getElementById('layersDropdown').classList.toggle('show')

    /** Handle the button status */
    const button = map.mapProperties.buttonsToolbar.find(
      x => x.id === 'showLayers'
    )

    /** Check if the button has been found */
    if (!button) return

    /** Change the status and color of the button */
    handleButtonStatus(button, map)
  }
}
