export default function getGeojsonExtent(geojson) {
  if (!geojson) return

  /** Get the features to iterate */
  const entities = geojson.features

  /** Set a couple of lists to store the degrees */
  const longitudeArray = []
  const latitudeArray = []

  /** Iterate each feature and get it geometries */
  entities.forEach(entity => {
    longitudeArray.push(entity.geometry.coordinates[0])
    latitudeArray.push(entity.geometry.coordinates[1])
  })

  /** Get the extreme values of the longitude and latitude arrays */
  const highestLongitude = Math.max(...longitudeArray)
  const lowestLongitude = Math.min(...longitudeArray)
  const highestLatitude = Math.max(...latitudeArray)
  const lowestLatitude = Math.min(...latitudeArray)

  /** Return the extent */
  return {
    west: lowestLongitude,
    south: lowestLatitude,
    east: highestLongitude,
    north: highestLatitude
  }
}
