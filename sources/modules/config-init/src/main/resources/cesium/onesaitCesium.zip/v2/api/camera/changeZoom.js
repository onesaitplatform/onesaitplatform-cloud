import getCurrentHeight from './getCurrentHeight.js'

export default function changeZoom(type, map) {
  if (!map || !type || (type !== 'plus' && type !== 'minus')) return

  /** Get the current camera altitude */
  const currentHeight = getCurrentHeight(map)

  if (type === 'plus') {
    if (currentHeight >= 1000) {
      map.camera.zoomIn(currentHeight / 10)
    }
  } else {
    map.camera.zoomOut(currentHeight / 10)
  }
}
