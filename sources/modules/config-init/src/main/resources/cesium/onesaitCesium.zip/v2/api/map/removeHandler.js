export default function removeHandler(map, id) {
  if (!map) return

  /** Check if any handler exists */
  if (map.mapProperties.handlers.length === 0) return

  /** Check if a specific handler will be destroy, or all of them */
  if (id) {
    const handler = map.mapProperties.handlers.find(x => x.config.id === id)

    if (handler) {
      map.mapProperties.handlers = map.mapProperties.handlers.filter(
        x => !x.config.id === id
      )
      handler.destroy()
    }
  } else {
    map.mapProperties.handlers.forEach(handler => {
      handler.destroy()
    })
    map.mapProperties.handlers.length = 0
  }
}
