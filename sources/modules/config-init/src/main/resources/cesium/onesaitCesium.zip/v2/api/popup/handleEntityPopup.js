export default function handleEntityPopup(map, entity, position) {
  /** Check if the popup will open based in if input params exists and the
   * selected entity has at least one property to show. If not, close it */
  const open =
    position &&
    entity &&
    map &&
    entity.properties &&
    entity.properties.propertyNames.length > 0

  /** Create the div element */
  let div = document.getElementById('popup')
  if (!div) div = createDiv(map)

  /** Check if the popup will be opened or closed */
  open ? openPopup(div, entity, position, map) : closePopup(div, map)
}

function createDiv(map) {
  /** Create the popup DIV element and configure it */
  const popup = document.createElement('div')
  popup.id = 'popup'
  popup.className = 'popup'
  popup.style.display = 'none'
  popup.style.position = 'absolute'
  popup.style.visibility = 'hidden'
  popup.style['pointer-events'] = 'none'
  popup.position = undefined

  /** Add the popup to the map container */
  map.container.appendChild(popup)

  return popup
}

function openPopup(div, entity, position, map) {
  /** Transform the map position into canvas coordinates */
  const canvasPosition = map.scene.cartesianToCanvasCoordinates(position)

  const ellipsoid = map.scene.globe.ellipsoid
  const cartographic = ellipsoid.cartesianToCartographic(position)
  const longitude = Cesium.Math.toDegrees(cartographic.longitude)
  const latitude = Cesium.Math.toDegrees(cartographic.latitude)
  map.mapProperties.popup.position = [longitude, latitude]
  map.mapProperties.popup.opened = true

  /** Update the popup div position */
  div.style.left = canvasPosition.x + 'px'
  div.style.top = canvasPosition.y + 'px'

  /** Update the popup content and properties */
  div.style.display = 'block'
  div.innerHTML = fillPopupContent(entity)

  /** Get the size of the popup */
  const popupWidth = div.offsetWidth
  const popupHeight = div.offsetHeight

  /** Adjust dynamically the position of the popup */
  div.style.left = canvasPosition.x - popupWidth / 2 + 'px'
  div.style.top = canvasPosition.y - popupHeight - 30 + 'px'

  /** Show the popup */
  div.style.visibility = 'visible'
}

function closePopup(div, map) {
  if (div) {
    /** Disable the popup */
    div.style.left = '0px'
    div.style.top = '0px'
    div.style.display = 'none'
    div.style.visibility = 'hidden'

    map.mapProperties.popup.position = undefined
    map.mapProperties.popup.opened = false
  }
}

function fillPopupContent(entity) {
  const properties = entity.properties.getValue()
  let content = ''

  for (const property in properties) {
    const value = entity.properties[property].getValue()
    content += '<p><strong>' + property + '</strong>: ' + value + '</p>'
  }

  return content
}
