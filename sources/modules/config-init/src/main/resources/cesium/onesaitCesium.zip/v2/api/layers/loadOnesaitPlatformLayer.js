import loadAgsMapServer from './loadAgsMapServer.js'
import loadGeojson from './loadGeojson.js'
import loadIonAsset from './loadIonAsset.js'
import loadWms from './loadWms.js'

export default function loadOnesaitPlatformLayer(inputConfig, map) {
  if (!inputConfig || !inputConfig.layerId || !inputConfig.basePath || !map)
    return

  /** Set the necessary variables */
  const layerId = inputConfig.layerId
  const basePath = inputConfig.basePath
  let query = inputConfig.query

  /** Set the URL for calling to the layer */
  let url = basePath + '/layer/getLayerData?layer=' + layerId

  /** Check if the layer will have a query */
  if (query && query != 'null') {
    /** Parse the query */
    query = JSON.parse(query)

    /** Iterate the query */
    /** TODO: update to Object forEach */
    for (let i = 0; i < query.length; i++) {
      let field = query[i]['param']
      let value = query[i]['default']
      url += '&' + field + '=' + value
    }
  }

  /** LEGACY */
  /** TODO: change to ES6 Fetch API */
  $.ajax({
    url: url,
    type: 'GET',
    dataType: 'json',
    contentType: 'application/json',
    async: false,
    headers: {
      'Content-Type': 'application/json'
    },
    success: function (result) {
      var data = result
      var type = data['typeGeometry'].toLowerCase()
      if (
        data['heatMap']['radius'] == undefined ||
        data['heatMap']['radius'] == null
      ) {
        var size = data['symbology']['pixelSize']
        var colorIn = data['symbology']['innerColorHEX']
        var alphaIn = data['symbology']['innerColorAlpha']
        var colorOut = data['symbology']['outlineColorHEX']
        var outSize = data['symbology']['outlineWidth']
        var alphaOut = data['symbology']['outerColorAlpha']
      } else {
        var weithField = 'value'
        var min = data['heatMap']['min']
        var max = data['heatMap']['max']
        var radius = data['heatMap']['radius']
      }

      /** NEW */
      if (type === 'agsms') {
        const url = data.url // 'https://sit.laspalmasgc.es/server/rest/services/opendata/barrios/MapServer
        const id = data.id // 'barrios_lpgc'
        const name = data.name // 'Barrios LPGC'

        loadAgsMapServer(
          {
            url: url,
            id: id,
            name: name
          },
          map
        )
      } else if (type === 'asset') {
        const code = data.code // 96188
        const id = data.id // 'osm_buildings'
        const name = data.name // 'Edificios 3D'

        loadIonAsset(
          {
            code: code,
            id: id,
            name: name
          },
          map
        )
      } else if (type === 'heatmap') {
        /** Clear the incoming legacy object */
        const geojson = data
        const id = geojson.name
        const name = geojson.name
        const properties = geojson.properties

        loadHeatmap({
          json: geojson,
          id: id,
          name: name,
          properties: properties
        })
      } else if (
        /** Check if the layer to load will be vectorial */
        type === 'point' ||
        type === 'linestring' ||
        type === 'polygon'
      ) {
        /** Clear the incoming legacy object */
        const geojson = data
        const symbology = geojson.symbology
        const id = geojson.name
        const name = geojson.name

        symbology.name =
          symbology.name === 'simbPointBasic' ? 'singleSymbol' : symbology.name

        delete geojson.symbology

        loadGeojson(
          {
            json: geojson,
            id: id,
            name: name,
            symbology: symbology
          },
          map
        )
      } else if (type === 'wms') {
        const url = data.url
        const layers = data.layers
        const id = data.name
        const name = data.name

        loadWms(
          {
            url: url,
            layers: layers,
            id: id,
            name: name
          },
          map
        )
      }
    },
    error: function (req, status, err) {
      console.error('something went wrong', req.responseText, status, err)
    }
  })
}
