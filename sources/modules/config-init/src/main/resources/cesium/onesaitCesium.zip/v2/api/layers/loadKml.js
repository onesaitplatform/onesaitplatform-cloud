import updateLayersDropdown from '../ui/updateLayersDropdown.js'

export default function loadKml(inputConfig, map) {
  if (!map || !inputConfig || !inputConfig.url || !inputConfig.id) return

  /** Set the params */
  const url = inputConfig.url
  const id = inputConfig.id
  const name = inputConfig.name ? inputConfig.name : inputConfig.id

  const layer = map.dataSources.add(
    Cesium.KmlDataSource.load(url, {
      camera: map.scene.camera,
      canvas: map.scene.canvas,
      ellipsoid: map.scene.globe.ellipsoid,
      clampToGround: true
    })
  )

  /** Add the layer properties */
  layer.layerProperties = {}
  layer.layerProperties.id = id
  layer.layerProperties.name = name
  layer.layerProperties.type = 'kml'

  /** Add the layer to the map and the map list */
  map.mapProperties.layers.vector.push(layer)

  /** Add the layer to the layers dropdown */
  updateLayersDropdown({
    id: id,
    name: name,
    type: 'kml'
  })
}
