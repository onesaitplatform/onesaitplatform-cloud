import getEntityGeometry from './getEntityGeometry.js'

export function selectEntity(entity) {
  /** Get the entity geometry */
  const geometry = getEntityGeometry(entity)

  /** Update the symbology */
  switch (geometry) {
    case 'point':
      entity.point.color.setValue(
        Cesium.Color.fromCssColorString('#55ffff').withAlpha(0.6)
      )
      break

    case 'linestring':
      entity.polyline.material.color.setValue(
        Cesium.Color.fromCssColorString('#55ffff').withAlpha(0.6)
      )
      break

    case 'polygon':
      entity.polygon.material.color.setValue(
        Cesium.Color.fromCssColorString('#55ffff').withAlpha(0.6)
      )
      break
  }
}

export function unselectEntity(entity) {
  /** Get the entity geometry */
  const geometry = getEntityGeometry(entity)

  switch (geometry) {
    case 'point':
      entity.point.color.setValue(entity.entityProperties.symbology.color)
      break

    case 'linestring':
      entity.polyline.material.color.setValue(
        entity.entityProperties.symbology.material
      )
      break

    case 'polygon':
      entity.polygon.material.color.setValue(
        entity.entityProperties.symbology.material
      )
      break
  }
}
