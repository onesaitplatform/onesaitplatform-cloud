import getGeojsonExtent from '../gp/getGeojsonExtent.js'
import updateLayersDropdown from '../ui/updateLayersDropdown.js'

export default function loadHeatmap(inputConfig, map) {
  if (
    !inputConfig ||
    !inputConfig.json ||
    !inputConfig.id ||
    !inputConfig.properties ||
    !map
  )
    return

  const json = inputConfig.json
  const id = inputConfig.id
  const name = inputConfig.name ? inputConfig.name : inputConfig.id
  const properties = inputConfig.properties
  const weightField = properties.weightField
  const valueMin = properties.valueMin
  const valueMax = properties.valueMax

  /** Check if the json is empty */
  if (json.features.length === 0) return

  /** Get the extent of the layer */
  const layerExtent = getGeojsonExtent(json)

  /** Set the properties of the heatmap */
  const heatmapProperties = {
    radius: properties.radius,
    minOpacity: 0.2,
    maxOpacity: 0.7
  }

  /** Set the heatmap data */
  const heatmapData = getWeights(json.features, weightField)

  /** Create the heatmap */
  const layer = CesiumHeatmap.create(map, layerExtent, heatmapProperties)

  layer.setWGS84Data(valueMin, valueMax, heatmapData)

  /** Add the layer properties */
  layer._layer.layerProperties = {}
  layer._layer.layerProperties.id = id
  layer._layer.layerProperties.name = name
  layer._layer.layerProperties.type = 'heatmap'

  /** Add the layer to the map and the map list */
  map.mapProperties.layers.heatmaps.push(layer._layer)

  /** Add the layer to the layers dropdown */
  updateLayersDropdown({
    id: id,
    name: name,
    type: 'heatmap'
  })
}

function getWeights(entities, weightField) {
  const list = []

  entities.forEach(entity => {
    const longitude = entity.geometry.coordinates[0]
    const latitude = entity.geometry.coordinates[1]
    const weight = entity.properties[weightField]

    if (weight)
      list.push({
        x: longitude,
        y: latitude,
        value: weight
      })
  })

  return list
}
