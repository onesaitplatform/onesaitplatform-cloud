export default function updateLayersDropdown(inputConfig) {
  if (!inputConfig || !inputConfig.id || !inputConfig.name || !inputConfig.type)
    return

  /** Get the layers dropdown DIV elements */
  const layersDropdown = document.getElementById('layersDropdown')
  const showLayers = document.getElementById('showLayers')

  if (!layersDropdown || !showLayers) return

  const id = inputConfig.id
  const name = inputConfig.name
  const type = inputConfig.type
  const geometry = inputConfig.geometry
  const symbology = inputConfig.symbology

  switch (type) {
    case 'vector':
      addVectorRow(id, name, geometry, symbology, layersDropdown)
      break
    case 'assetIon':
    case 'heatmap':
    case 'image':
    case 'kml':
    case 'wms':
      addCustomRow(id, name, type, layersDropdown)
      break
  }

  /** Enable the map legend button if disabled */
  if (showLayers.classList.contains('disabled')) {
    showLayers.classList.remove('disabled')
  }
}

function addVectorRow(
  layerId,
  layerName,
  geometryType,
  symbology,
  layersDropdown
) {
  /** Update the geometry type */
  geometryType = geometryType === 'polyline' ? 'linestring' : geometryType

  /** Create the DIV container */
  const layerDiv = document.createElement('div')
  layerDiv.id = layerId
  layerDiv.className = 'layerItem'

  /** Create the icon DIV */
  const className = geometryType + 'Icon'
  const iconDiv = document.createElement('div')
  iconDiv.className = className

  /** Update the icon color */
  switch (className) {
    case 'pointIcon':
    case 'polygonIcon':
      iconDiv.style.backgroundColor = symbology
      break
    case 'linestringIcon':
      iconDiv.style.borderBottomColor = symbology
      break
  }

  /** Create the layer name DIV */
  const layerSpan = document.createElement('span')
  layerSpan.className = 'layerName'
  layerSpan.innerText = layerName

  /** Create the layer check DIV */
  const checkmark = document.createElement('div')
  checkmark.className = 'layerCheck'

  /** Add the icon DIV to the container DIV */
  layerDiv.appendChild(iconDiv)
  layerDiv.appendChild(layerSpan)
  layerDiv.appendChild(checkmark)

  layersDropdown.appendChild(layerDiv)
}

function addCustomRow(layerId, layerName, layerType, layersDropdown) {
  /** Create the DIV container */
  const layerDiv = document.createElement('div')
  layerDiv.id = layerId
  layerDiv.className = 'layerItem'

  /** Create the icon DIV */
  const className = layerType + 'Icon'
  const iconDiv = document.createElement('div')
  iconDiv.className = className

  const layerSpan = document.createElement('span')
  layerSpan.className = 'layerName'
  layerSpan.innerText = layerName

  /** Create the layer check DIV */
  const checkmark = document.createElement('div')
  checkmark.className = 'layerCheck'

  /** Add the icon DIV to the container DIV */
  layerDiv.appendChild(iconDiv)
  layerDiv.appendChild(layerSpan)
  layerDiv.appendChild(checkmark)

  layersDropdown.appendChild(layerDiv, layersDropdown.childNodes[0])
}
