export default function removeMapEntities(map) {
  if (!map || map.entities.values.length === 0) return

  map.entities.removeAll()
}
