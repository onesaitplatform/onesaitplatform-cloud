export default function getLayersByAttribute(key, value, map) {
  if (!key || !value || !map) return

  /** Get the map layers */
  const mapLayers = map.mapProperties.layers

  /** Set a list to store the found layers */
  const layers = []

  const layerTypes = ['assets', 'heatmaps', 'imagery', 'vector', 'wms']

  /** Iterate each type of layers */
  layerTypes.forEach(type => {
    /** Check if exists layers of this type */
    if (mapLayers[type].length > 0) {
      mapLayers[type]
        .filter(x => x.layerProperties[key] === value)
        .forEach(layer => layers.push(layer))
    }
  })

  /** Return the list of layers */
  return layers
}
