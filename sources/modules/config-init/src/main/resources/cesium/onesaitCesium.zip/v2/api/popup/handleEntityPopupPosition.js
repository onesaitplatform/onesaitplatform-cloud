export default function handleEntityPopupPosition(map) {
  if (!map) return

  /** Create the handler */
  const handler = new Cesium.ScreenSpaceEventHandler(map.scene.canvas)

  /** Listen the mouse movement */
  handler.setInputAction(() => {
    updatePosition(map)
  }, Cesium.ScreenSpaceEventType.MOUSE_MOVE)

  handler.setInputAction(() => {
    updatePosition(map)
  }, Cesium.ScreenSpaceEventType.WHEEL)
}

function updatePosition(map) {
  /** Get the popup and it status */
  const popup = document.getElementById('popup')
  const opened = map.mapProperties.popup.opened

  /** If exists and is opened */
  if (popup && opened) {
    /** Get the canvas position of the popup */
    const currentPosition = map.mapProperties.popup.position
    const newCanvasPosition = Cesium.Cartesian3.fromDegrees(
      currentPosition[0],
      currentPosition[1]
    )
    const newCanvasCoords = Cesium.SceneTransforms.wgs84ToWindowCoordinates(
      map.scene,
      newCanvasPosition
    )

    /** Get the size of the popup */
    const popupWidth = popup.offsetWidth
    const popupHeight = popup.offsetHeight

    /** Adjust dynamically the position of the popup */
    popup.style.left = newCanvasCoords.x - popupWidth / 2 + 'px'
    popup.style.top = newCanvasCoords.y - popupHeight - 30 + 'px'

    const newCartesian = map.camera.pickEllipsoid(
      newCanvasCoords,
      map.scene.globe.ellipsoid
    )

    const cartographic = Cesium.Cartographic.fromCartesian(newCartesian)
    const longitude = Cesium.Math.toDegrees(cartographic.longitude)
    const latitude = Cesium.Math.toDegrees(cartographic.latitude)

    map.mapProperties.popup.position = [longitude, latitude]
  }
}
