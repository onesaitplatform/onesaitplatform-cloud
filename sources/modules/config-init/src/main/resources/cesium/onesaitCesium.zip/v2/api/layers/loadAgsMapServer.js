export default function loadAgsMapServer(inputConfig, map) {
  if (!map || !inputConfig || !inputConfig.url || !inputConfig.id) return

  /** Set the params */
  const url = inputConfig.url
  const id = inputConfig.id
  const name = inputConfig.name ? inputConfig.name : inputConfig.id
  const layers = inputConfig.layers ? inputConfig.layers : undefined

  /** Create the layer config input */
  const config = {}
  config.url = url
  if (layers) config.layers = layers

  /** Create the layer from the service */
  const agsMapService = new Cesium.ArcGisMapServerImageryProvider(config)

  /** Set the layer properties */
  agsMapService.layerProperties = {}
  agsMapService.layerProperties.id = id
  agsMapService.layerProperties.name = name
  agsMapService.layerProperties.layers = layers
  agsMapService.layerProperties.type = 'imagery'

  /** Add the layer to the viewer */
  map.imageryLayers.addImageryProvider(agsMapService)

  /** Add the layer to the layer list */
  map.mapProperties.layers.imagery.push(agsMapService)
}
