import zoomToPosition from './zoomToPosition.js'

export default function setInitZoom(inputConfig, map) {
  if (!inputConfig || !inputConfig.coordinates || !inputConfig.height || !map)
    return

  const coordinates = inputConfig.coordinates
  const height = inputConfig.height

  /** Make the zoom */
  zoomToPosition(
    {
      coordinates: coordinates,
      height: height
    },
    map
  )

  /** Update the map properties */
  map.mapProperties.homeView.coordinates = coordinates
  map.mapProperties.homeView.height = height
}
