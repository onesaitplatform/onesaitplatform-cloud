import updateLayersDropdown from '../ui/updateLayersDropdown.js'

export default function loadImage(inputConfig, map) {
  if (
    !map ||
    !inputConfig ||
    !inputConfig.url ||
    !inputConfig.id ||
    !inputConfig.position
  )
    return

  /** Set the params */
  const url = inputConfig.url
  const id = inputConfig.id
  const name = inputConfig.name ? inputConfig.name : inputConfig.id
  const position = {
    west: inputConfig.position.west,
    north: inputConfig.position.north,
    east: inputConfig.position.east,
    south: inputConfig.position.south
  }

  const layer = map.imageryLayers.addImageryProvider(
    new Cesium.SingleTileImageryProvider({
      url: url,
      // rectangle: Cesium.Rectangle.fromDegrees(-75.0, 28.0, -67.0, 29.75)
      rectangle: Cesium.Rectangle.fromDegrees(
        position.west,
        position.north,
        position.east,
        position.south
      )
    })
  )

  /** Add the layer properties */
  layer.layerProperties = {}
  layer.layerProperties.id = id
  layer.layerProperties.name = name
  layer.layerProperties.type = 'image'

  /** Add the layer to the map and the map list */
  map.mapProperties.layers.imagery.push(layer)

  /** Add the layer to the layers dropdown */
  updateLayersDropdown({
    id: id,
    name: name,
    type: 'image'
  })
}
