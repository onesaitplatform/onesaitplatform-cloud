import handleButtonStatus from '../ui/handleButtonStatus.js'
import handleEntityPopup from '../popup/handleEntityPopup.js'
import {
  selectEntity,
  unselectEntity
} from '../selection/changeSelectionSymbology.js'
import calculateCentroid from '../gp/calculateCentroid.js'

export default function selectByAttributes(map) {
  if (!map) return

  if (!document.getElementById('layersDropdown').hasChildNodes()) return

  /** Handle the button status */
  const button = map.mapProperties.buttonsToolbar.find(
    x => x.id === 'selectByAttributes'
  )

  /** Check if the button has been found */
  if (!button) return

  /** Change the status and color of the button */
  handleButtonStatus(button, map)

  document
    .getElementById('selectByAttributesPanel')
    .classList.toggle('showFlex')

  /** Check if the button is ON or OFF */
  button.pushed
    ? initSelectByAttributes(map)
    : endSelectByAttributes(button, map)
}

function initSelectByAttributes(map) {
  const inputLayer = document.getElementById('selectByAttributesLayers')
  const propertiesList = document.getElementById('selectByAttributesField')
  const inputValue = document.getElementById('selectByAttributesValue')
  const button = document.getElementById('selectByAttributesButton')
  const text = document.getElementById('selectByAttributesResult')

  inputLayer.addEventListener('change', event => {
    if (event.inputType == 'insertReplacementText' || event.inputType == null) {
      /** Try to get the name of the layers and check if is undefined */
      const layerName = event.target.value
      if (!layerName) return

      /** Try to get the layer and check if is undefined */
      const layer = map.mapProperties.layers.vector.find(
        x => x.layerProperties.name === layerName
      )
      if (!layer || layer.entities.values.length === 0) {
        const newOption = document.createElement('option')
        newOption.value = 'empty'
        newOption.innerHTML = 'Empty Layer'
        newOption.disabled = true
        propertiesList.appendChild(newOption)
        return
      }

      /** Clear the properties list and shettle again with the layer properties */
      while (
        propertiesList.firstChild &&
        propertiesList.removeChild(propertiesList.firstChild)
      );

      Object.values(layer.entities.values[0].properties.propertyNames).forEach(
        key => {
          const newOption = document.createElement('option')
          newOption.value = key
          newOption.innerHTML = key
          propertiesList.appendChild(newOption)
        }
      )
    }
  })

  button.addEventListener('click', () => {
    const layerName = inputLayer.value
    const key = propertiesList.value
    const value = inputValue.value

    /** Check that all variables are defined */
    if (!layerName || !key || !value) return

    /** Get the layer by it name */
    const layer = map.mapProperties.layers.vector.find(
      x => x.layerProperties.name === layerName
    )

    /** Look for the entity with the matched key & value */
    const entity = layer.entities.values.find(
      x => x.properties[key].getValue() == value
    )

    /** Check if the entity has been found */
    if (!entity) {
      /** Update the message text */
      text.innerHTML = 'Entity not found'

      if (map.mapProperties.selectedEntity) {
        /** Change the symbology to default one */
        unselectEntity(map.mapProperties.selectedEntity)

        /** Force close popup */
        handleEntityPopup(map)

        /** Clear entity selection references */
        map.mapProperties.selectedEntity = undefined
        map.selectedEntity = undefined
      }
      return
    }

    /** Update the message text */
    text.innerHTML = '1 entity found!'

    /** Change the symbology to selected one */
    selectEntity(entity)

    /** Open the popup, using the centroid as coordinates */
    const centroid = calculateCentroid(entity)
    handleEntityPopup(map, entity, centroid)

    /** Update the entity selection references */
    map.selectedEntity = entity
    map.mapProperties.selectedEntity = entity
  })
}

function endSelectByAttributes(button, map) {
  /** Change the symbology to default one */
  unselectEntity(map.mapProperties.selectedEntity)

  /** Force close popup */
  handleEntityPopup(map)

  /** Clear entity selection references */
  map.mapProperties.selectedEntity = undefined
  map.selectedEntity = undefined

  const inputLayer = document.getElementById('selectByAttributesLayers')
  inputLayer.value = 'Choose a layer'

  const propertiesList = document.getElementById('selectByAttributesField')
  const inputValue = document.getElementById('selectByAttributesValue')
  const text = document.getElementById('selectByAttributesResult')
  text.innerHTML = ''
}
