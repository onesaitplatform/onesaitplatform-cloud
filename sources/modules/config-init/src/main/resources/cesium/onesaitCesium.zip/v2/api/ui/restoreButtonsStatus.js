export default function restoreButtonStatus(currentButton, map) {
  if (!map) return

  /** Get the active buttons */
  const activeButtons = document.getElementsByClassName('buttonActive')

  /** Get the map buttons list */
  const listButtons = map.mapProperties.buttonsToolbar

  /** Get the pushed button ID */
  const currentButtonId = currentButton.id

  /** Iterate each active button */
  Object.values(activeButtons).forEach(button => {
    /** Get the button ID and get the buttom from the list with the same ID. Also
     * get if the button will remain switched on */
    const buttonId = button.id
    const storedButton = listButtons.find(x => x.id === buttonId)
    const standAlone = storedButton.standAlone

    /** Check if the button is not the same, and will not remain switched on */
    if (buttonId !== currentButtonId && !standAlone) {
      /** Update the button property in the map list */
      storedButton.pushed = false

      /** Change the style to default button*/
      button.className = button.className.replace('buttonActive', 'button')
    }
  })
}
