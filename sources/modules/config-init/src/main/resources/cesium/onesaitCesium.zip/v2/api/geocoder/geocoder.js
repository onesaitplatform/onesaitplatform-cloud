export default function geocoder(address, map) {
  if (!address || !map) return

  /** Get the datalist with the candidates */
  const candidatesList = document.getElementById('geocoderCandidates')

  if (!candidatesList) return

  /** Set the default URL */
  let query = 'https://nominatim.openstreetmap.org/search?q='

  /** Add the address */
  query += address

  /** Add the format of the query */
  query += '&format=jsonv2'

  /** Fetch the query */
  fetch(query)
    .then(response => response.json())
    .then(data => {
      if (data.length === 0) return

      data.forEach(candidate => {
        const newOption = document.createElement('option')
        newOption.value = candidate.display_name
        newOption.className = 'geocoderItem'
        newOption.dataset.position = candidate.lat + ',' + candidate.lon
        candidatesList.appendChild(newOption)
      })
    })
}
