import changeZoom from './camera/changeZoom.js'
import getCurrentHeight from './camera/getCurrentHeight.js'
import getCurrentPosition from './camera/getCurrentPosition.js'
import getUserPosition from './camera/getUserPosition.js'
import setInitZoom from './camera/setInitZoom.js'
import zoomToPosition from './camera/zoomToPosition.js'

import geocoder from './geocoder/geocoder.js'
import handleGeocoder from './geocoder/handleGeocoder.js'

import calculateArea from './gp/calculateArea.js'
import calculateCentroid from './gp/calculateCentroid.js'
import getGeojsonExtent from './gp/getGeojsonExtent.js'

import getLayerType from './layers/getLayerType.js'
import loadAgsMapServer from './layers/loadAgsMapServer.js'
import loadBasemap from './layers/loadBasemap.js'
import loadGeojson from './layers/loadGeojson.js'
import loadHeatmap from './layers/loadHeatmap.js'
import loadImage from './layers/loadImage.js'
import loadIonAsset from './layers/loadIonAsset.js'
import loadKml from './layers/loadKml.js'
import loadOnesaitPlatformLayer from './layers/loadOnesaitPlatformLayer.js'
import loadWms from './layers/loadWms.js'
import removeLayer from './layers/removeLayer.js'

import initMap from './map/initMap.js'
import removeHandler from './map/removeHandler.js'
import removeMapEntities from './map/removeMapEntities.js'

import cursorCoordinates from './measure/cursorCoordinates.js'
import measureArea from './measure/measureArea.js'
import measureDistance from './measure/cursorCoordinates.js'

import handleEntityPopup from './popup/handleEntityPopup.js'
import handleEntityPopupPosition from './popup/handleEntityPopupPosition.js'

import getLayersByAttribute from './search/getLayersByAttribute.js'

import {
  selectEntity,
  unselectEntity
} from './selection/changeSelectionSymbology.js'
import getEntityGeometry from './selection/getEntityGeometry.js'
import handleEntitySelection from './selection/handleEntitySelection.js'
import selectByAttributes from './selection/selectByAttributes.js'

import handleButtonStatus from './ui/handleButtonStatus.js'
import handleLayersDropdown from './ui/handleLayersDropdown.js'
import handleLegend from './ui/handleLegend.js'
import handleToolbars from './ui/handleToolbars.js'
import restoreButtonStatus from './ui/restoreButtonsStatus.js'
import updateLayersDropdown from './ui/updateLayersDropdown.js'

export const onesaitCesium = {
  camera: {
    changeZoom: changeZoom,
    getCurrentHeight: getCurrentHeight,
    getCurrentPosition: getCurrentPosition,
    getUserPosition: getUserPosition,
    setInitZoom: setInitZoom,
    zoomToPosition: zoomToPosition
  },
  geocoder: {
    geocoder: geocoder,
    handleGeocoder: handleGeocoder
  },
  gp: {
    calculateArea: calculateArea,
    calculateCentroid: calculateCentroid,
    getGeojsonExtent: getGeojsonExtent
  },
  layers: {
    getLayerType: getLayerType,
    loadAgsMapServer: loadAgsMapServer,
    loadBasemap: loadBasemap,
    loadGeojson: loadGeojson,
    loadKml: loadKml,
    loadHeatmap: loadHeatmap,
    loadImage: loadImage,
    loadIonAsset: loadIonAsset,
    loadOnesaitPlatformLayer: loadOnesaitPlatformLayer,
    loadWms: loadWms,
    removeLayer: removeLayer
  },
  map: {
    initMap: initMap,
    removeHandler: removeHandler,
    removeMapEntities: removeMapEntities
  },
  measure: {
    cursorCoordinates: cursorCoordinates,
    measureArea: measureArea,
    measureDistance: measureDistance
  },
  popup: {
    handleEntityPopup: handleEntityPopup,
    handleEntityPopupPosition: handleEntityPopupPosition
  },
  search: {
    getLayersByAttribute: getLayersByAttribute
  },
  selection: {
    selectEntity: selectEntity,
    unselectEntity: unselectEntity,
    getEntityGeometry: getEntityGeometry,
    handleEntitySelection: handleEntitySelection,
    selectByAttributes: selectByAttributes
  },
  ui: {
    handleButtonStatus: handleButtonStatus,
    handleLayersDropdown: handleLayersDropdown,
    handleLegend: handleLegend,
    handleToolbars: handleToolbars,
    restoreButtonStatus: restoreButtonStatus,
    updateLayersDropdown: updateLayersDropdown
  }
}
