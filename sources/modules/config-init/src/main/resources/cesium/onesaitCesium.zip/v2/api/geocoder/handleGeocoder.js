import geocoder from './geocoder.js'
import zoomToPosition from '../camera/zoomToPosition.js'

export default function handleGeocoder(map) {
  if (!map) return

  const input = document.getElementById('geocoderAddressInput')

  if (!input) return

  const candidates = document.getElementById('geocoderCandidates')

  input.addEventListener('change', event => {
    const address = event.target.value

    if (address.length === 0) {
      while (
        candidates.firstChild &&
        candidates.removeChild(candidates.firstChild)
      );
    }

    if (address.length < 3) return

    geocoder(address, map)
  })

  input.addEventListener('input', event => {
    if (event.inputType == 'insertReplacementText' || event.inputType == null) {
      if (event.target.value) {
        const addressToFind = event.target.value
        const candidateList = candidates.querySelectorAll('option')

        const foundAddress = Object.values(candidateList).find(
          x => x.value === addressToFind
        )

        if (foundAddress) {
          const position = [
            foundAddress.dataset.position.split(',')[1],
            foundAddress.dataset.position.split(',')[0]
          ]

          const coordinates = Cesium.Cartesian3.fromDegrees(
            position[0],
            position[1]
          )

          const billboard =
            'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAXIAAAEyCAMAAADQoqtXAAAAh1BMVEUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD3YishAAAALXRSTlMA/vwCsxUg++sLKPfBo3VuRt+rUc7SzciOQxDvgg0H2taxmok5M5ZIF+a2Z1g8qKPrAAADW0lEQVR42uzBgQAAAACAoP2pF6kCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABm196WEgfCIAB390AggIQzrhyEVUss3//9lk2imwhYezHjVX8XVAF3zV+dmWHMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzM7H8E7PcIsB8yn0oiJU3nsOTCWjybjkZTnmntWU9sJnK2Q203IzWDpZOTekfLu8gclsiAXOLCkhzAkhiIBa4oKGeeRE5OcNUvd0saZIEbChIW3R0PuOnAO1hsEhq25PbLtxbZqFUrj5T42KqWESwusfWGACn8Q495ZK/s4EMmTgMQplSGDx1OYDEd2EWtEO9RuqcK1Lo8wNL0ypp8Qe2FXLtZEqECSkMqx6e9OEQpyEvzuNSv6kPsBzSEPlVVTt9THlXgAmdzcYYvZtS8Ot3yyXlMgcuqPOa4MKeCI49PGwAPVK/X26BheP5AfACwcbHEVU3yShJ5wqcuKWnlx2cCdaAhhCO7AMbSsoz8GELwIjGFFTNUOuwCY4ocAl12UMm4gsX0zFEzcjHHhnkj8hGfYVFJzcgp4DcHfyP36W0qR26/i3zLIywy6rvIvV5J4IlvdeQngApl5Kc68jc+waLrcVJFLonli6Qq8lf2YPHlEs4KthQ4k3ypIok7LnDVwv/vpyJmuCLzxjOZjLr1S1gKVYNc7xtL4sZzcud9Z1KTy9Vgz7cp0upzjJYx+7CkSLT4zm1q1VS3p97Sanf3xDv99NorFGkH+9POvaw0DIRhGJ7vV6o2VTyANlV04QnE+78+sWk3QqmLJKvn2QQy61m8zMw/ucvct517pT+PykLpz2uRUvpzGrpf6c9r6P4LpX/E6N1/ls/GPIYCUvozS5T+DO6+ukr23Z+r/euJ6r6MwpnAR1VSqcc26Lo2qEolVR+NMX1XqntatAOW665S343RvCXro9sgLoKO4kBmOuifWqUd4k35NG6T93bEe2Kw2YhWlTpdtoOWp5Uyq2JUm5tKql7W/ebPQr9+qUrqZtMYWf9Q+VWV1FZSu18PfWMaz/3r6jxVlWT7OV+9Xj83pnbSBgYNAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/8QMqRBZEgPNAWAAAAABJRU5ErkJggg=='

          const userPoint = map.entities.add({
            name: 'geocoderAddress',
            position: coordinates,
            billboard: {
              image: billboard,
              heightReference: Cesium.HeightReference.CLAMP_TO_GROUND,
              disableDepthTestDistance: Number.POSITIVE_INFINITY
            }
          })

          const zoomConfig = {
            coordinates: [position[0], position[1]],
            height: 1000,
            animated: true
          }

          setTimeout(() => {
            zoomToPosition(zoomConfig, map)
            setTimeout(() => vanishAction(userPoint, map), 5000)
          }, 500)
        }
      }

      event.target.value = ''

      while (
        candidates.firstChild &&
        candidates.removeChild(candidates.firstChild)
      );
    }
  })
}

function vanishAction(entity, map) {
  let alpha = 1
  const interval = setInterval(vanishing, 100)

  function vanishing() {
    alpha -= 0.05
    entity.billboard.color = new Cesium.Color(1.0, 1.0, 1.0, alpha)
    if (alpha <= 0.05) {
      clearInterval(interval)
      map.entities.remove(entity)
    }
  }
}
